# # CpeErrorValidation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cod** | **string** | Codigo de error | [optional]
**msg** | **string** | Mensaje de error para el usuario | [optional]
**errors** | [**\Greenter\Sunat\GRE\Model\CpeError[]**](CpeError.md) | Array de errores y descripcion del error | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
