# # StatusResponseError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**num_error** | **string** | Número de error encontrado para el envío realizado | [optional]
**des_error** | **string** | Detalle del error encontrado para el envío realizado | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
