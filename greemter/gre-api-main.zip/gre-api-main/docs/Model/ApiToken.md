# # ApiToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **string** |  | [optional]
**token_type** | **string** |  | [optional]
**expires_in** | **int** | El tiempo de expiración en segundos. Concluído el tiempo podrá generar un nuevo token | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
