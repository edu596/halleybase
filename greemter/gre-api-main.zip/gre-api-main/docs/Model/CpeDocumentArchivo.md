# # CpeDocumentArchivo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nom_archivo** | **string** | Nombre del archivo zip enviado. Estructura: RRRRRRRRRRR-TT-SSSS-NNNNNNNN.zip | [optional]
**arc_gre_zip** | **string** | Archivo zip enviado (en base64) | [optional]
**hash_zip** | **string** | Hash del archivo zip enviado, usando SHA-256 | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
