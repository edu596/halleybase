# # CpeResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**num_ticket** | **string** | Numero de ticket (UUID) generado por el envío realizado. | [optional]
**fec_recepcion** | **\DateTime** | Fecha de recepción de envío del comprobante. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
