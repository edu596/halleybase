-- MySQL dump 10.16  Distrib 10.1.21-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `almacen`
--

DROP TABLE IF EXISTS `almacen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almacen` (
  `idalmacen` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idempresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`idalmacen`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almacen`
--

LOCK TABLES `almacen` WRITE;
/*!40000 ALTER TABLE `almacen` DISABLE KEYS */;
INSERT INTO `almacen` VALUES (1,'PRINCIPAL','PRINCIPAL',1);
/*!40000 ALTER TABLE `almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articulo`
--

DROP TABLE IF EXISTS `articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulo` (
  `idarticulo` int(11) NOT NULL AUTO_INCREMENT,
  `idalmacen` int(11) NOT NULL,
  `codigo_proveedor` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `idfamilia` int(11) NOT NULL,
  `unidad_medida` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `costo_compra` float(12,2) NOT NULL,
  `saldo_iniu` float(12,2) DEFAULT NULL,
  `valor_iniu` float(12,2) DEFAULT NULL,
  `saldo_finu` float(12,2) DEFAULT NULL,
  `valor_finu` float(12,2) DEFAULT NULL,
  `stock` float(12,2) DEFAULT NULL,
  `comprast` float(12,2) DEFAULT NULL,
  `ventast` float(12,2) DEFAULT NULL,
  `portador` float(12,2) DEFAULT NULL,
  `merma` float(12,2) DEFAULT NULL,
  `precio_venta` float(12,2) DEFAULT NULL,
  `imagen` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) DEFAULT '1',
  `valor_fin_kardex` float(12,2) DEFAULT NULL,
  `precio_final_kardex` float(12,2) DEFAULT NULL,
  `fecharegistro` datetime NOT NULL,
  `codigosunat` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ccontable` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `precio2` float(14,2) DEFAULT NULL,
  `precio3` float(14,2) DEFAULT NULL,
  `costofinal` float(14,2) DEFAULT NULL,
  `cicbper` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nticbperi` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ctticbperi` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mticbperu` float(14,2) DEFAULT NULL,
  `codigott` varchar(50) COLLATE utf8_unicode_ci DEFAULT '1000',
  `desctt` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'IGV Impuesto general a las ventas',
  `codigointtt` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'VAT',
  `nombrett` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'IGV',
  `lote` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marca` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechafabricacion` date DEFAULT NULL,
  `fechavencimiento` date DEFAULT NULL,
  `procedencia` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fabricante` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registrosanitario` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaingalm` date DEFAULT NULL,
  `fechafinalma` date DEFAULT NULL,
  `proveedor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seriefaccompra` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numerofaccompra` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechafacturacompra` date DEFAULT NULL,
  PRIMARY KEY (`idarticulo`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `fk_producto_familia_idx` (`idfamilia`),
  KEY `fk_producto_almacen_idx` (`idalmacen`),
  CONSTRAINT `fk_producto_almacen` FOREIGN KEY (`idalmacen`) REFERENCES `almacen` (`idalmacen`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_producto_familia` FOREIGN KEY (`idfamilia`) REFERENCES `familia` (`idfamilia`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo`
--

LOCK TABLES `articulo` WRITE;
/*!40000 ALTER TABLE `articulo` DISABLE KEYS */;
INSERT INTO `articulo` VALUES (1,1,'1000ncdg','1000ncdg','1000ncdg',1,'0',0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'0',1,0.00,0.00,'2018-10-11 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000','IGV Impuesto general a las ventas','VAT','IGV',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,'-','SR02','SERVICIOS',5,'NIU',1.00,1000000.00,1.00,1000000.00,1.00,1000000.00,0.00,0.00,0.00,0.00,1.00,'',1,NULL,NULL,'2019-09-02 00:00:00','-','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(3,1,'-','ICBPER','BOLSAS PLASTICAS',5,'MTR',0.10,100000.00,10000.00,100000.00,10000.00,100000.00,NULL,NULL,NULL,NULL,0.10,'',1,NULL,NULL,'2019-09-09 00:00:00',NULL,NULL,NULL,NULL,NULL,'7152','ICBPER','OTH',0.10,'7152','Impuesto al consumo de bolsas de plástico','OTH','ICBPER',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,1,'-','PAA1','PILA AAA',3,'NIU',5.00,1000.00,5000.00,935.00,4675.00,935.00,0.00,65.00,0.00,0.00,10.00,'',1,4675.00,5.00,'2020-06-26 10:48:03','-','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(5,1,'-','CORE 2 DUO 1','PILA AA',6,'NIU',5.00,600.00,3000.00,467.00,2335.00,467.00,0.00,133.00,0.00,0.00,25.00,'',1,2335.00,5.00,'2020-06-27 09:15:45','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(6,1,'-','BLL1','BILLETERAS',6,'NIU',15.00,500.00,7500.00,500.00,7500.00,500.00,0.00,0.00,0.00,0.00,25.00,'',1,7500.00,15.00,'2020-07-24 11:04:14','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(7,1,'-','PRUEBA2','PRUEBA4',6,'NIU',0.00,100.00,0.00,100.00,0.00,100.00,0.00,0.00,0.00,0.00,0.00,'',1,0.00,0.00,'2020-07-24 12:42:10','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(8,1,'-','prueba4','prueba4',3,'NIU',0.00,100.00,0.00,100.00,0.00,100.00,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000','IGV Impuesto general a las ventas','VAT','IGV',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,1,'-','LJ01','LIJAS',3,'NIU',10.00,1000.00,10000.00,924.00,9240.00,924.00,0.00,76.00,0.00,0.00,15.00,'',1,9240.00,10.00,'2020-07-24 14:48:16','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(10,1,'0','SLL1','SILLAS',3,'NIU',0.00,100.00,0.00,100.00,0.00,100.00,0.00,0.00,0.00,0.00,15.00,'',1,0.00,0.00,'2020-07-24 14:53:31','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(11,1,'0','CM01','CEMENTO',3,'NIU',0.00,100.00,0.00,100.00,0.00,100.00,0.00,0.00,0.00,0.00,0.00,'',1,0.00,0.00,'2020-07-27 09:26:29','-','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(12,1,'-','PH01','IPHONE',6,'NIU',18.00,100.00,1800.00,100.00,1800.00,100.00,0.00,0.00,0.00,0.00,250.00,'',1,1800.00,18.00,'2020-07-29 09:09:48','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00'),(13,1,'-','VS012','VAOSOS',3,'NIU',25.00,8000.00,200000.00,7977.00,199425.00,7977.00,0.00,23.00,0.00,0.00,200.00,'',1,199425.00,25.00,'2020-07-29 09:12:36','','',0.00,0.00,NULL,'','','',0.00,'1000','IGV Impuesto General a las Ventas','VAT','IGV','','','0000-00-00','0000-00-00','','','','0000-00-00','0000-00-00','','','','0000-00-00');
/*!40000 ALTER TABLE `articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boleta`
--

DROP TABLE IF EXISTS `boleta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boleta` (
  `idboleta` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `fecha_emision_01` datetime NOT NULL,
  `firma_digital_36` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `idempresa` int(11) NOT NULL,
  `tipo_documento_06` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numeracion_07` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `codigo_tipo_15_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monto_15_2` float(12,2) DEFAULT NULL,
  `sumatoria_igv_18_1` float(12,2) DEFAULT NULL,
  `sumatoria_igv_18_2` float(12,2) DEFAULT NULL,
  `codigo_tributo_18_3` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_tributo_18_4` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_internacional_18_5` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `importe_total_23` float(12,2) NOT NULL,
  `codigo_leyenda_26_1` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion_leyenda_26_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_documento_25_1` int(11) DEFAULT NULL,
  `guia_remision_25` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_ubl_37` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_estructura_38` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_moneda_24` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tasa_igv` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `tipodocuCliente` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rucCliente` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RazonSocial` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `comentario_baja` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdescuento` float(12,2) DEFAULT NULL,
  `vendedorsitio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcambio` float(14,2) DEFAULT NULL,
  `tipopago` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nroreferencia` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ipagado` float(14,2) DEFAULT NULL,
  `saldo` float(14,2) DEFAULT NULL,
  `icbper` float(14,2) NOT NULL,
  `CodigoRptaSunat` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DetalleSunat` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idboleta`),
  UNIQUE KEY `numeracion_07` (`numeracion_07`),
  KEY `fk_boleta_empresa_idx` (`idempresa`),
  KEY `fk_boleta_usuario_idx` (`idusuario`),
  KEY `fk_boleta_usuario_idx1` (`idcliente`),
  CONSTRAINT `boleta_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `persona` (`idpersona`),
  CONSTRAINT `fk_boleta_empresa` FOREIGN KEY (`idempresa`) REFERENCES `empresa` (`idempresa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boleta_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boleta`
--

LOCK TABLES `boleta` WRITE;
/*!40000 ALTER TABLE `boleta` DISABLE KEYS */;
INSERT INTO `boleta` VALUES (1,1,'2020-06-29 11:16:39','44477344',1,'03','B001-1',1,'1001',84.75,15.25,15.25,'1000','IGV','VAT',100.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'EMITIDO'),(2,1,'2020-07-01 10:38:03','44477344',1,'03','B001-2',1,'1001',29.66,5.34,5.34,'1000','IGV','VAT',35.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',4,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'XML firmado'),(3,1,'2020-07-02 17:19:51','44477344',1,'03','B001-3',1,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',4,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'XML firmado'),(4,1,'2020-07-03 09:28:58','44477344',1,'03','B001-4',1,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',4,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'XML firmado'),(5,1,'2020-07-10 11:30:17','44477344',1,'03','B001-5',1,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',3,'0','99999999','CLIENTES VARIOS','2020-07-10 11:30:23','asdasd',0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,'3','C/Baja'),(6,1,'2020-07-10 14:01:54','44477344',1,'03','B001-6',1,'1001',21.19,3.81,3.81,'1000','IGV','VAT',25.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'EMITIDO'),(7,1,'2020-07-31 15:26:54','44477344',1,'03','B001-7',1,'1001',15.00,0.00,0.00,'9997','EXO','VAT',15.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'EMITIDO'),(8,1,'2020-08-10 16:33:23','44477344',1,'03','B001-8',1,'1001',169.49,30.51,30.51,'1000','IGV','VAT',200.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',5,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,'0','La Boleta numero B001-8, ha sido aceptada'),(9,1,'2020-08-10 16:33:41','44477344',1,'03','B001-9',1,'1001',12.71,2.29,2.29,'1000','IGV','VAT',15.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',5,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,'0','La Boleta numero B001-9, ha sido aceptada'),(10,1,'2020-08-10 16:33:52','44477344',1,'03','B001-10',1,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',5,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,'0','La Boleta numero B001-10, ha sido aceptada'),(11,1,'2020-08-10 17:07:47','44477344',1,'03','B001-11',1,'1001',12.71,2.29,2.29,'1000','IGV','VAT',15.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'EMITIDO'),(12,1,'2020-08-10 17:07:57','44477344',1,'03','B001-12',1,'1001',169.49,30.51,30.51,'1000','IGV','VAT',200.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'EMITIDO'),(13,1,'2020-08-12 09:56:17','44477344',1,'03','B001-13',1,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,0.00,NULL,'EMITIDO');
/*!40000 ALTER TABLE `boleta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boletaservicio`
--

DROP TABLE IF EXISTS `boletaservicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boletaservicio` (
  `idboleta` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `fecha_emision_01` datetime NOT NULL,
  `firma_digital_36` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `idempresa` int(11) NOT NULL,
  `tipo_documento_06` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numeracion_07` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `codigo_tipo_15_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monto_15_2` float(12,2) DEFAULT NULL,
  `sumatoria_igv_18_1` float(12,2) DEFAULT NULL,
  `sumatoria_igv_18_2` float(12,2) DEFAULT NULL,
  `codigo_tributo_18_3` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_tributo_18_4` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_internacional_18_5` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `importe_total_23` float(12,2) NOT NULL,
  `codigo_leyenda_26_1` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion_leyenda_26_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_documento_25_1` int(11) DEFAULT NULL,
  `guia_remision_25` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_ubl_37` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_estructura_38` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_moneda_24` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tasa_igv` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `tipodocuCliente` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rucCliente` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RazonSocial` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `comentario_baja` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdescuento` float(12,2) DEFAULT NULL,
  `vendedorsitio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcambio` float(14,2) DEFAULT NULL,
  `icbper` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`idboleta`),
  UNIQUE KEY `numeracion_07` (`numeracion_07`),
  KEY `fk_boleta_empresa_idx` (`idempresa`),
  KEY `fk_boleta_usuario_idx` (`idusuario`),
  KEY `fk_boleta_usuario_idx1` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boletaservicio`
--

LOCK TABLES `boletaservicio` WRITE;
/*!40000 ALTER TABLE `boletaservicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `boletaservicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja`
--

DROP TABLE IF EXISTS `caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caja` (
  `idcaja` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `montoi` float(14,2) DEFAULT NULL,
  `montof` decimal(14,2) DEFAULT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `idempresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`idcaja`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja`
--

LOCK TABLES `caja` WRITE;
/*!40000 ALTER TABLE `caja` DISABLE KEYS */;
/*!40000 ALTER TABLE `caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo1`
--

DROP TABLE IF EXISTS `catalogo1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo1` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `un1001` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo1`
--

LOCK TABLES `catalogo1` WRITE;
/*!40000 ALTER TABLE `catalogo1` DISABLE KEYS */;
INSERT INTO `catalogo1` VALUES ('01','FACTURA','380'),('03','BOLETA','346'),('07','NOTACRE.','381'),('08','NOTADEB.','383'),('09','GUIA DE REMISIÓN REMITENTE',''),('12','TICKET \n\nDE MAQUINA REGISTRADORA',''),('13','DOCUMENTO EMITIDO POR BANCOS U OTROS',''),('18','SBS',''),('20','COTIZACION',NULL),('30','DOCUMENTO DE COBRANZA',NULL),('31','DOCUMENTOS EMITIDOS POR LAS AFP',''),('50','NOTA DE PEDIDO',NULL),('56','GUIA REMISION TRANSPORTISTA',''),('99','OSERVICIO',NULL);
/*!40000 ALTER TABLE `catalogo1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo10`
--

DROP TABLE IF EXISTS `catalogo10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo10` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo10`
--

LOCK TABLES `catalogo10` WRITE;
/*!40000 ALTER TABLE `catalogo10` DISABLE KEYS */;
INSERT INTO `catalogo10` VALUES ('01','INTERESES POR MORA'),('02','AUMENTO EN EL VALOR'),('03','PENALIDADES/OTROS CONCEPTOS');
/*!40000 ALTER TABLE `catalogo10` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo11`
--

DROP TABLE IF EXISTS `catalogo11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo11` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo11`
--

LOCK TABLES `catalogo11` WRITE;
/*!40000 ALTER TABLE `catalogo11` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo12`
--

DROP TABLE IF EXISTS `catalogo12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo12` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo12`
--

LOCK TABLES `catalogo12` WRITE;
/*!40000 ALTER TABLE `catalogo12` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo12` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo14`
--

DROP TABLE IF EXISTS `catalogo14`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo14` (
  `codigo` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo14`
--

LOCK TABLES `catalogo14` WRITE;
/*!40000 ALTER TABLE `catalogo14` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo14` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo15`
--

DROP TABLE IF EXISTS `catalogo15`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo15` (
  `codigo` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo15`
--

LOCK TABLES `catalogo15` WRITE;
/*!40000 ALTER TABLE `catalogo15` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo15` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo16`
--

DROP TABLE IF EXISTS `catalogo16`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo16` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo16`
--

LOCK TABLES `catalogo16` WRITE;
/*!40000 ALTER TABLE `catalogo16` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo16` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo17`
--

DROP TABLE IF EXISTS `catalogo17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo17` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo17`
--

LOCK TABLES `catalogo17` WRITE;
/*!40000 ALTER TABLE `catalogo17` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo17` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo18`
--

DROP TABLE IF EXISTS `catalogo18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo18` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo18`
--

LOCK TABLES `catalogo18` WRITE;
/*!40000 ALTER TABLE `catalogo18` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo18` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo19`
--

DROP TABLE IF EXISTS `catalogo19`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo19` (
  `codigo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo19`
--

LOCK TABLES `catalogo19` WRITE;
/*!40000 ALTER TABLE `catalogo19` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo19` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo5`
--

DROP TABLE IF EXISTS `catalogo5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo5` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unece5153` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo5`
--

LOCK TABLES `catalogo5` WRITE;
/*!40000 ALTER TABLE `catalogo5` DISABLE KEYS */;
INSERT INTO `catalogo5` VALUES (1,'1000','IGV','VAT',1),(2,'1016','IVAP',NULL,0),(3,'2000','ISC','EXC',0),(4,'9996','GRA','GRA',0),(5,'9997','EXO','VAT',1),(6,'9998','INA','INA',0),(7,'9999','OTROS','OTH',0);
/*!40000 ALTER TABLE `catalogo5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo6`
--

DROP TABLE IF EXISTS `catalogo6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo6` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abrev` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo6`
--

LOCK TABLES `catalogo6` WRITE;
/*!40000 ALTER TABLE `catalogo6` DISABLE KEYS */;
INSERT INTO `catalogo6` VALUES ('0','DOC.TRIB.NO.DOM.SIN.RUC',NULL),('1','DNI',NULL),('4','CARNET DE EXTRANJERIA',NULL),('6','RUC',NULL),('7','PASAPORTE',NULL);
/*!40000 ALTER TABLE `catalogo6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo7`
--

DROP TABLE IF EXISTS `catalogo7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo7` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo7`
--

LOCK TABLES `catalogo7` WRITE;
/*!40000 ALTER TABLE `catalogo7` DISABLE KEYS */;
INSERT INTO `catalogo7` VALUES ('10','GRAVADO - OPERACION ONEROSA'),('11','GRAVADO - RETIRO POR PREMIO'),('12','GRAVADO - RETIRO POR \n\nDONACION'),('13','GRAVADO - RETIRO'),('14','GRAVADO - RETIRO POR PUBLICIDAD'),('15','GRAVADO - BONIFICACIONES'),('16','GRAVADO - RETIRO POR ENTREGA A TRABAJADORES'),('17','GRAVADO - IVAP'),('20','EXONERADO - OPERACION ONEROSA'),('21','EXONERADO - TRANSFERENCIA GRATUITA'),('30','INAFECTO - OPERACION ONEROSA'),('31','INAFECTO - RETIRO POR \n\nBONIFICACION'),('32','INAFECTO - RETIRO'),('33','INAFECTO - RETIRO POR MUESTRAS MEDICAS'),('34','INAFECTO - RETIRIO \n\nPOR CONVENIO COLECTIVO'),('35','INAFECTO - RETIRO POR PREMIO'),('36','INAFECTO - RETIRO POR PUBLICIDAD'),('40','EXPORTACION');
/*!40000 ALTER TABLE `catalogo7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo8`
--

DROP TABLE IF EXISTS `catalogo8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo8` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo8`
--

LOCK TABLES `catalogo8` WRITE;
/*!40000 ALTER TABLE `catalogo8` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogo8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo9`
--

DROP TABLE IF EXISTS `catalogo9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogo9` (
  `codigo` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo9`
--

LOCK TABLES `catalogo9` WRITE;
/*!40000 ALTER TABLE `catalogo9` DISABLE KEYS */;
INSERT INTO `catalogo9` VALUES ('01','ANULACIÓN DE LA OPERACIÓN'),('02','ANULACIÓN POR ERROR EN EL RUC'),('03','CORRECCIÓN POR ERROR EN LA DESCRIPCIÓN'),('04','DESCUENTO GLOBAL'),('05','DESCUENTO POR ITEM'),('06','DEVOLUCIÓN TOTAL'),('07','DEVOLUCIÓN POR ITEM'),('08','BONIFICACIÓN'),('09','DISMININUCIÓN EN EL VALOR'),('10','OTROS CONCEPTOS');
/*!40000 ALTER TABLE `catalogo9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria_plato`
--

DROP TABLE IF EXISTS `categoria_plato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_plato` (
  `idcategoria` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombreCategoria` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_plato`
--

LOCK TABLES `categoria_plato` WRITE;
/*!40000 ALTER TABLE `categoria_plato` DISABLE KEYS */;
INSERT INTO `categoria_plato` VALUES (1,'ENTRADA',1),(2,'FONDO',1),(3,'POSTRE',1);
/*!40000 ALTER TABLE `categoria_plato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ciudad`
--

DROP TABLE IF EXISTS `ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ciudad` (
  `idciudad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `iddepartamento` int(11) NOT NULL,
  PRIMARY KEY (`idciudad`),
  KEY `fk_ciudad_departamento_idx` (`iddepartamento`),
  CONSTRAINT `fk_ciudad_departamento` FOREIGN KEY (`iddepartamento`) REFERENCES `departamento` (`iddepartamento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudad`
--

LOCK TABLES `ciudad` WRITE;
/*!40000 ALTER TABLE `ciudad` DISABLE KEYS */;
INSERT INTO `ciudad` VALUES (1,'BAGUA GRANDE',1),(2,'CHACHAPOYAS',1),(3,'CHIMBOTE',2),(4,'HUARAZ',2),(5,'CASMA',2),(6,'ABANCAY',3),(7,'ANDAHUAYLAS',3),(8,'AREQUIPA',4),(9,'CAMANA',4),(10,'ISLAY',4),(11,'AYACUCHO',5),(12,'HUANTA',5),(13,'CAJAMARCA',6),(14,'JAÉN',6),(15,'CUSCO',7),(16,'CANCHIS',7),(17,'LA CONVENCIÓN',7),(18,'YAURI',7),(19,'HUANCAVELICA',8),(20,'HUÁNUCO',9),(21,'LEONCIO PRADO',9),(22,'ICA',10),(23,'CHINCHA ALTA',10),(24,'PISCO',10),(25,'NAZCA',10),(26,'HUANCAYO',11),(27,'TARMA',11),(28,'LA OROYA',11),(29,'JAUJA',11),(30,'TRUJILLO',12),(31,'CHEPÉN',12),(32,'GUADALUPE',12),(33,'CASA GRANDE',12),(34,'PACASMAYO',12),(35,'HUAMACHUCO',12),(36,'LAREDO',12),(37,'MOCHE',12),(38,'CHICLAYO',13),(39,'LAMBAYEQUE',13),(40,'FERREÑAFE',13),(41,'TUMAN',13),(42,'MONSEFU',13),(43,'LIMA METROPOLITANA',14),(44,'HUACHO',14),(45,'HUARAL',14),(46,'SAN VICENTE DE CAÑETE',14),(47,'BARRANCA',14),(48,'HUAURA',14),(49,'PARAMONGA',14),(50,'CHANCAY',14),(51,'MALA',14),(52,'SUPE',14),(53,'IQUITOS',15),(54,'YURIMAGUAS',15),(55,'PUERTO MALDONADO',16),(56,'ILO',17),(57,'MOQUEGUA',17),(58,'CERRO DE PASCO',18),(59,'PIURA',19),(60,'SULLANA',19),(61,'TALARA',19),(62,'CATACAOS',19),(63,'PAITA',19),(64,'CHULUCANAS',19),(65,'SECHURA',19),(66,'JULIACA',20),(67,'PUNO',20),(68,'AYAVIRI',20),(69,'ILAVE',20),(70,'TARAPOTO',21),(71,'MOYOBAMBA',21),(72,'RIOJA',21),(73,'TACNA',22),(74,'TUMBES',23),(75,'PUCALPA',24),(76,'S/C',25);
/*!40000 ALTER TABLE `ciudad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra` (
  `idcompra` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `tipo_documento` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `idproveedor` int(11) NOT NULL,
  `serie` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `guia` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subtotal` float(12,2) NOT NULL,
  `igv` float(12,2) NOT NULL,
  `total` float(12,2) NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `subtotal_$` float(14,2) DEFAULT NULL,
  `igv_$` float(14,2) DEFAULT NULL,
  `total_$` float(14,2) DEFAULT NULL,
  `tcambio` float(14,3) DEFAULT NULL,
  `moneda` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idempresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`idcompra`),
  KEY `fk_proveedor_persona_idx` (`idproveedor`),
  KEY `fk_compra_usuario_idx` (`idusuario`),
  CONSTRAINT `fk_compra_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_proveedor_persona` FOREIGN KEY (`idproveedor`) REFERENCES `persona` (`idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuraciones`
--

DROP TABLE IF EXISTS `configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuraciones` (
  `idconfiguracion` int(11) NOT NULL AUTO_INCREMENT,
  `idempresa` int(11) NOT NULL,
  `porDesc` float(14,2) NOT NULL,
  `igv` float(14,2) NOT NULL,
  PRIMARY KEY (`idconfiguracion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuraciones`
--

LOCK TABLES `configuraciones` WRITE;
/*!40000 ALTER TABLE `configuraciones` DISABLE KEYS */;
INSERT INTO `configuraciones` VALUES (1,1,0.00,18.00);
/*!40000 ALTER TABLE `configuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `correo`
--

DROP TABLE IF EXISTS `correo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `correo` (
  `idcorreo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtpsecure` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `mensaje` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idcorreo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `correo`
--

LOCK TABLES `correo` WRITE;
/*!40000 ALTER TABLE `correo` DISABLE KEYS */;
INSERT INTO `correo` VALUES (1,'Usuario informatico','tecnologo@tecnologosperu.com','mail.tecnologosperu.com','000000','tls',587,'aqui su mensaje personalizado');
/*!40000 ALTER TABLE `correo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cotizacion`
--

DROP TABLE IF EXISTS `cotizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cotizacion` (
  `idcotizacion` int(11) NOT NULL AUTO_INCREMENT,
  `idempresa` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `serienota` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `moneda` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaemision` datetime NOT NULL,
  `tipocotizacion` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subtotal` float(14,2) NOT NULL,
  `impuesto` float(14,2) NOT NULL,
  `total` float(14,2) NOT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `vendedor` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipocambio` float(14,3) DEFAULT NULL,
  `fechavalidez` date DEFAULT NULL,
  PRIMARY KEY (`idcotizacion`),
  KEY `fk_cotizacion_persona` (`idcliente`),
  KEY `fk_cotizacion_empresa` (`idempresa`),
  CONSTRAINT `fk_cotizacion_empresa` FOREIGN KEY (`idempresa`) REFERENCES `empresa` (`idempresa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cotizacion_persona` FOREIGN KEY (`idcliente`) REFERENCES `persona` (`idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cotizacion`
--

LOCK TABLES `cotizacion` WRITE;
/*!40000 ALTER TABLE `cotizacion` DISABLE KEYS */;
INSERT INTO `cotizacion` VALUES (2,1,1,3,'CT01-2','PEN','2020-07-07 11:59:30','producto',16.95,3.05,20.00,'',3,'',0.000,'2020-07-07'),(3,1,1,3,'CT01-3','USD','2020-07-07 16:35:16','producto',16.95,3.05,20.00,'adasdasd',1,'',3.549,'2020-07-07'),(4,1,1,3,'CT01-4','PEN','2020-07-17 11:18:13','producto',25.42,4.58,30.00,'asdasdasd',1,'',0.000,'2020-07-17'),(5,1,1,3,'CT01-5','PEN','2020-07-14 14:27:34','producto',33.90,6.10,40.00,'',1,'',0.000,'2020-07-14'),(6,1,1,3,'CT01-6','PEN','2020-07-14 17:48:43','producto',50.85,9.15,60.00,'aasfasfasf',1,'',0.000,'2020-07-14'),(7,1,1,3,'CT01-7','USD','2020-07-14 17:51:56','producto',84.75,15.25,100.00,'dfdshdfshshsf',1,'',3.517,'2020-07-14'),(8,1,1,3,'CT01-8','PEN','2020-07-14 17:53:05','servicio',0.00,0.00,0.00,'wqdadasd',1,'',0.000,'2020-07-14'),(9,1,1,3,'CT01-9','PEN','2020-07-17 11:20:23','producto',25.42,4.58,30.00,'asdasdasd',1,'',0.000,'2020-07-17'),(10,1,1,3,'CT01-10','PEN','2020-07-17 12:16:12','producto',33.90,6.10,40.00,'hkhjkgh',1,'',0.000,'2020-07-17'),(11,1,1,3,'CT01-11','PEN','2020-07-17 12:35:22','producto',55.93,10.07,66.00,'eduardo',1,'',0.000,'2020-07-17'),(12,1,1,3,'CT01-12','PEN','2020-07-22 10:35:00','producto',329.66,59.34,389.00,'sadasdasdasdasdasdasd',1,'',0.000,'2020-07-22'),(13,1,1,3,'CT01-13','PEN','2020-07-24 10:44:20','producto',25.42,4.58,30.00,'asd',1,'',0.000,'2020-07-24'),(14,1,1,3,'CT01-14','USD','2020-07-24 11:39:05','producto',397.46,71.54,469.00,'yyyyyyyyyyyyyyyyyy',1,'',3.510,'2020-07-24'),(15,1,1,3,'CT01-15','PEN','2020-07-24 17:07:41','producto',318.64,57.36,376.00,'',1,'',0.000,'2020-07-24'),(16,1,1,3,'CT01-16','PEN','2020-07-24 17:38:38','producto',105.93,19.07,125.00,'asdasdasdasdasdasd',1,'',0.000,'2020-07-24'),(17,1,1,3,'CT01-17','PEN','2020-07-24 17:44:33','producto',80.51,14.49,95.00,'asdasd',1,'',0.000,'2020-07-24'),(18,1,1,3,'CT01-18','PEN','2020-07-24 17:45:22','producto',8.47,1.53,10.00,'asdas',1,'',0.000,'2020-07-24'),(19,1,1,3,'CT01-19','PEN','2020-07-24 17:45:40','servicio',0.00,0.00,0.00,'asdfasfasf',1,'',0.000,'2020-07-24'),(20,1,1,3,'CT01-19','PEN','2020-07-24 17:53:30','producto',42.37,7.63,50.00,'',1,'',0.000,'2020-07-24'),(21,1,1,3,'CT01-20','PEN','2020-07-24 13:07:39','producto',0.00,0.00,0.00,'sdasdasd',2,'',0.000,'2020-07-24'),(22,1,1,3,'CT01-21','PEN','2020-07-24 17:56:24','producto',42.37,7.63,50.00,'dasfsdf',1,'',0.000,'2020-07-24'),(23,1,1,3,'CT01-22','PEN','2020-07-24 17:56:56','producto',211.86,38.14,250.00,'sdfsdfsdfdfsdfsdfsdf',1,'',0.000,'2020-07-24'),(24,1,1,3,'CT01-23','USD','2020-07-24 16:22:04','producto',635.59,114.41,750.00,'asdasdasdasd',2,'',3.250,'2020-07-24'),(25,1,1,3,'CT01-24','PEN','2020-08-06 17:18:45','producto',0.00,0.00,0.00,'asdasdasd',2,'',0.000,'2020-08-06'),(26,1,1,3,'CT01-25','PEN','2020-08-06 11:59:35','producto',63.56,11.44,75.00,'dfsdf',1,'',0.000,'2020-08-06'),(27,1,1,3,'CT01-26','PEN','2020-08-06 11:57:22','producto',847.46,152.54,1000.00,'',1,'',0.000,'2020-08-06'),(28,1,1,3,'CT01-27','USD','2020-08-06 12:00:00','producto',101.69,18.31,120.00,'asdasdasd',1,'',3.550,'2020-08-06'),(29,1,1,3,'CT01-28','USD','2020-08-10 11:08:11','producto',76.27,13.73,90.00,'gnbfghfgh',1,'',3.551,'2020-08-10'),(30,1,1,3,'CT01-29','PEN','2020-08-10 11:31:32','producto',63.56,11.44,75.00,'adasfasf',2,'',0.000,'2020-08-10'),(31,1,1,3,'CT01-30','PEN','2020-08-10 12:00:43','producto',305.08,54.92,360.00,'asdasdasdasdasd asd asd asd asd asd as',2,'',0.000,'2020-08-10'),(32,1,1,3,'CT01-31','PEN','2020-08-12 16:00:52','producto',847.46,152.54,1000.00,'asdasd',1,'',0.000,'2020-08-12');
/*!40000 ALTER TABLE `cotizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departamento`
--

DROP TABLE IF EXISTS `departamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departamento` (
  `iddepartamento` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iddepartamento`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departamento`
--

LOCK TABLES `departamento` WRITE;
/*!40000 ALTER TABLE `departamento` DISABLE KEYS */;
INSERT INTO `departamento` VALUES (1,'AMAZONAS'),(2,'ANCASH'),(3,'APURIMAC'),(4,'AREQUIPA'),(5,'AYACUCHO'),(6,'CAJAMARCA'),(7,'CUSCO'),(8,'HUANCAVELICA'),(9,'HUANUCO'),(10,'ICA'),(11,'JUNÍN'),(12,'LA LIBERTAD'),(13,'LAMBAYEQUE'),(14,'LIMA'),(15,'LORETO'),(16,'MADRE DE DIOS'),(17,'MOQUEGUA'),(18,'PASCO'),(19,'PIURA'),(20,'PUNO'),(21,'SAN MARTÍN'),(22,'TACNA'),(23,'TUMBES'),(24,'UCAYALI'),(25,'S/D');
/*!40000 ALTER TABLE `departamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_articulo_cotizacion`
--

DROP TABLE IF EXISTS `detalle_articulo_cotizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_articulo_cotizacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcotizacion` int(11) NOT NULL,
  `iditem` int(11) NOT NULL,
  `codigo` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` float(14,2) NOT NULL,
  `descdet` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `norden` int(11) DEFAULT NULL,
  `valorunitario` float(14,5) DEFAULT NULL,
  `valorventa` float(14,2) DEFAULT NULL,
  `igvvalorventa` float(14,2) DEFAULT NULL,
  `igvitem` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cotizacion_detalle` (`idcotizacion`),
  CONSTRAINT `fk_cotizacion_detalle` FOREIGN KEY (`idcotizacion`) REFERENCES `cotizacion` (`idcotizacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_articulo_cotizacion`
--

LOCK TABLES `detalle_articulo_cotizacion` WRITE;
/*!40000 ALTER TABLE `detalle_articulo_cotizacion` DISABLE KEYS */;
INSERT INTO `detalle_articulo_cotizacion` VALUES (2,2,4,'PAA1',2,10.00,'',1,8.47458,16.95,NULL,NULL),(3,3,4,'PAA1',2,10.00,'',1,8.47458,16.95,NULL,NULL),(4,4,4,'PAA1',5,10.00,'',1,8.47458,42.37,NULL,NULL),(5,4,5,'CORE 2 DUO 1',1,25.00,'',2,21.18644,21.19,NULL,NULL),(6,5,4,'PAA1',4,10.00,'',1,8.47458,33.90,NULL,NULL),(7,9,4,'PAA1',2,10.00,'',1,8.47458,16.95,3.05,1.53),(8,9,5,'CORE 2 DUO 1',2,25.00,'',2,21.18644,42.37,7.63,3.81),(9,10,4,'PAA1',4,10.00,'',1,8.47458,33.90,6.10,1.53),(10,11,4,'PAA1',3,22.00,'',1,18.64407,55.93,10.07,3.36),(11,12,4,'PAA1',8,33.00,'',1,27.96610,223.73,40.27,5.03),(12,12,4,'PAA1',8,33.00,'',1,27.96610,223.73,40.27,5.03),(13,12,5,'CORE 2 DUO 1',5,25.00,'',2,21.18644,105.93,19.07,3.81),(14,13,4,'PAA1',3,10.00,'',0,8.47458,25.42,4.58,1.53),(23,14,4,'PAA1',8,10.00,'',1,8.47458,67.80,12.20,1.53),(24,14,5,'CORE 2 DUO 1',5,25.00,'',2,21.18644,105.93,19.07,3.81),(25,14,6,'BLL1',8,33.00,'',4,27.96610,223.73,40.27,5.03),(36,15,9,'LJ01',1,15.00,'',1,12.71186,12.71,2.29,2.29),(37,15,4,'PAA1',2,55.00,'',2,46.61017,93.22,16.78,8.39),(38,15,5,'CORE 2 DUO 1',3,25.00,'',3,21.18644,63.56,11.44,3.81),(39,15,10,'SLL1',6,22.00,'',4,18.64407,111.86,20.14,3.36),(40,15,7,'PRUEBA2',2,22.00,'',5,18.64407,37.29,6.71,3.36),(58,16,4,'PAA1',5,10.00,'',1,8.47458,42.37,7.63,1.53),(59,16,5,'CORE 2 DUO 1',3,25.00,'',2,21.18644,63.56,11.44,3.81),(63,17,4,'PAA1',2,10.00,'',1,8.47458,16.95,3.05,1.53),(64,17,5,'CORE 2 DUO 1',3,25.00,'',2,21.18644,63.56,11.44,3.81),(65,18,4,'PAA1',1,10.00,'',1,8.47458,8.47,1.53,1.53),(66,20,4,'PAA1',5,10.00,'',1,8.47458,42.37,7.63,1.53),(72,22,4,'PAA1',2,10.00,'',1,8.47458,16.95,3.05,1.53),(73,22,9,'LJ01',2,15.00,'',2,12.71186,25.42,4.58,2.29),(75,23,5,'CORE 2 DUO 1',10,25.00,'',1,21.18644,211.86,38.14,3.81),(84,21,9,'LJ01',3,15.00,'',1,0.00000,0.00,0.00,0.00),(86,24,5,'CORE 2 DUO 1',30,25.00,'',1,21.18644,635.59,114.41,3.81),(95,29,9,'LJ01',5,18.00,'',1,15.25424,76.27,13.73,2.75),(98,30,9,'LJ01',5,15.00,'',1,12.71186,63.56,11.44,2.29),(101,27,13,'VS012',5,200.00,'',1,169.49153,847.46,152.54,30.51),(102,26,9,'LJ01',5,15.00,'',1,12.71186,63.56,11.44,2.29),(104,28,9,'LJ01',8,15.00,'',1,12.71186,101.69,18.31,2.29),(107,31,9,'LJ01',20,18.00,'',1,15.25424,305.08,54.92,2.75),(108,32,13,'VS012',5,200.00,'',1,169.49153,847.46,152.54,30.51);
/*!40000 ALTER TABLE `detalle_articulo_cotizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_boleta_producto`
--

DROP TABLE IF EXISTS `detalle_boleta_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_boleta_producto` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idboleta` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `numero_orden_item_29` int(11) DEFAULT NULL,
  `cantidad_item_12` float(12,2) NOT NULL,
  `codigo_precio_14_1` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `precio_uni_item_14_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_monto_27_1` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_monto_27_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_3` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_4` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_5` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_6` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `igv_item` float(12,2) NOT NULL,
  `valor_uni_item_31` float(12,5) NOT NULL,
  `valor_venta_item_32` float(12,2) NOT NULL,
  `dcto_item` float(12,2) DEFAULT NULL,
  `descdet` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `fk_detalle_boleta_idx` (`idboleta`),
  KEY `fk_detalle_producto_idx` (`idarticulo`),
  CONSTRAINT `fk_detalleb_boleta` FOREIGN KEY (`idboleta`) REFERENCES `boleta` (`idboleta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalleb_producto` FOREIGN KEY (`idarticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_boleta_producto`
--

LOCK TABLES `detalle_boleta_producto` WRITE;
/*!40000 ALTER TABLE `detalle_boleta_producto` DISABLE KEYS */;
INSERT INTO `detalle_boleta_producto` VALUES (1,1,4,1,10.00,'01',10.00,15.25,15.25,'10','1000','IGV','VAT',1.53,8.47458,84.75,0.00,''),(2,2,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(3,2,5,2,1.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,21.19,0.00,''),(4,3,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(5,4,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(6,5,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(7,6,5,1,1.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,21.19,0.00,''),(8,7,9,1,1.00,'01',15.00,0.00,0.00,'20','9997','EXO','VAT',15.00,15.00000,15.00,0.00,''),(9,8,13,1,1.00,'01',200.00,30.51,30.51,'10','1000','IGV','VAT',30.51,169.49153,169.49,0.00,''),(10,9,9,1,1.00,'01',15.00,2.29,2.29,'10','1000','IGV','VAT',2.29,12.71186,12.71,0.00,''),(11,10,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(12,11,9,1,1.00,'01',15.00,2.29,2.29,'10','1000','IGV','VAT',2.29,12.71186,12.71,0.00,''),(13,12,13,1,1.00,'01',200.00,30.51,30.51,'10','1000','IGV','VAT',30.51,169.49153,169.49,0.00,''),(14,13,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,'');
/*!40000 ALTER TABLE `detalle_boleta_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_boleta_producto_ser`
--

DROP TABLE IF EXISTS `detalle_boleta_producto_ser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_boleta_producto_ser` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idboleta` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `numero_orden_item_29` int(11) DEFAULT NULL,
  `cantidad_item_12` float(12,2) NOT NULL,
  `codigo_precio_14_1` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `precio_uni_item_14_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_monto_27_1` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_monto_27_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_3` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_4` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_5` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_6` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `igv_item` float(12,2) NOT NULL,
  `valor_uni_item_31` float(12,5) NOT NULL,
  `valor_venta_item_32` float(12,2) NOT NULL,
  `dcto_item` float(12,2) DEFAULT NULL,
  `descdet` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `fk_detalle_boleta_idx` (`idboleta`),
  KEY `fk_detalle_producto_idx` (`idarticulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_boleta_producto_ser`
--

LOCK TABLES `detalle_boleta_producto_ser` WRITE;
/*!40000 ALTER TABLE `detalle_boleta_producto_ser` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_boleta_producto_ser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_compra_producto`
--

DROP TABLE IF EXISTS `detalle_compra_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_compra_producto` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idcompra` int(11) DEFAULT NULL,
  `idarticulo` int(11) DEFAULT NULL,
  `valor_unitario` float(12,3) DEFAULT NULL,
  `cantidad` float(12,2) DEFAULT NULL,
  `subtotal` float(12,2) DEFAULT NULL,
  `valor_unitario_$` float(14,2) DEFAULT NULL,
  `subtotal_$` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `fk_detalle_compra_idx` (`idcompra`),
  KEY `fk_detalle_producto_idx` (`idarticulo`),
  CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`idcompra`) REFERENCES `compra` (`idcompra`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`idarticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_compra_producto`
--

LOCK TABLES `detalle_compra_producto` WRITE;
/*!40000 ALTER TABLE `detalle_compra_producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_compra_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_doccobranza`
--

DROP TABLE IF EXISTS `detalle_doccobranza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_doccobranza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddoccobranza` int(11) NOT NULL,
  `iditem` int(11) NOT NULL,
  `codigo` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` float(14,2) NOT NULL,
  `descdet` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `norden` int(11) DEFAULT NULL,
  `igvvalorventa` float(14,2) DEFAULT NULL,
  `igvitem` float(14,2) DEFAULT NULL,
  `vuniitem` float(14,5) DEFAULT NULL,
  `valorventa` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_doccobranza`
--

LOCK TABLES `detalle_doccobranza` WRITE;
/*!40000 ALTER TABLE `detalle_doccobranza` DISABLE KEYS */;
INSERT INTO `detalle_doccobranza` VALUES (1,1,2,'SR02',1,45.00,'fgjfgjfgj',1,6.86,6.86,38.13559,38.14),(2,2,2,'SR02',1,85.00,'asdasdasdas',1,12.97,12.97,72.03390,72.03);
/*!40000 ALTER TABLE `detalle_doccobranza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_fac_art`
--

DROP TABLE IF EXISTS `detalle_fac_art`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_fac_art` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `numero_orden_item_33` int(11) NOT NULL,
  `cantidad_item_12` float(12,2) NOT NULL,
  `codigo_precio_15_1` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `precio_venta_item_15_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_16_1` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_16_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_16_3` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_item_16_4` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_item_16_5` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_item_16_6` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `igv_item` float(12,2) NOT NULL,
  `valor_uni_item_14` float(12,5) NOT NULL,
  `valor_venta_item_21` float(12,2) NOT NULL,
  `dcto_item` float(12,2) DEFAULT NULL,
  `descdet` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `fk_detalle_fact_idx` (`idfactura`),
  KEY `fk_detalle_prod_idx` (`idarticulo`),
  CONSTRAINT `fk_detallef_fact` FOREIGN KEY (`idfactura`) REFERENCES `factura` (`idfactura`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detallef_prod` FOREIGN KEY (`idarticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_fac_art`
--

LOCK TABLES `detalle_fac_art` WRITE;
/*!40000 ALTER TABLE `detalle_fac_art` DISABLE KEYS */;
INSERT INTO `detalle_fac_art` VALUES (1,1,4,1,2.00,'01',10.00,3.05,3.05,'10','1000','IGV','VAT',1.53,8.47458,16.95,0.00,''),(2,2,4,1,5.00,'01',10.00,7.63,7.63,'10','1000','IGV','VAT',1.53,8.47458,42.37,0.00,''),(3,3,4,1,10.00,'01',10.00,15.25,15.25,'10','1000','IGV','VAT',1.53,8.47458,84.75,0.00,''),(4,4,4,1,5.00,'01',10.00,7.63,7.63,'10','1000','IGV','VAT',1.53,8.47458,42.37,0.00,''),(5,4,5,2,8.00,'01',25.00,30.51,30.51,'10','1000','IGV','VAT',3.81,21.18644,169.49,0.00,''),(6,5,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(7,6,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(8,7,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(9,7,5,2,1.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,21.19,0.00,''),(10,8,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(11,9,2,1,1.00,'01',45.00,6.86,6.86,'10','1000','IGV','VAT',6.86,38.13559,38.14,0.00,'fgjfgjfgj'),(12,10,4,1,5.00,'01',10.00,7.63,7.63,'10','1000','IGV','VAT',1.53,8.47458,42.37,0.00,''),(13,11,5,1,2.00,'01',25.00,7.63,7.63,'10','1000','IGV','VAT',3.81,21.18644,42.37,0.00,''),(14,12,5,1,2.00,'01',25.00,7.63,7.63,'10','1000','IGV','VAT',3.81,21.18644,42.37,0.00,''),(15,13,4,1,5.00,'01',10.00,7.63,7.63,'10','1000','IGV','VAT',1.53,8.47458,42.37,0.00,''),(16,14,4,1,2.00,'01',10.00,3.05,3.05,'10','1000','IGV','VAT',1.53,8.47458,16.95,0.00,''),(17,15,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(18,16,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(19,17,5,1,1.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,21.19,0.00,''),(20,18,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(21,19,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(22,20,4,1,10.00,'01',10.00,15.25,15.25,'10','1000','IGV','VAT',1.53,8.47458,84.75,0.00,''),(23,21,9,1,1.00,'01',15.00,2.29,2.29,'10','1000','IGV','VAT',2.29,12.71186,12.71,0.00,''),(24,22,13,1,1.00,'01',200.00,30.51,30.51,'10','1000','IGV','VAT',30.51,169.49153,169.49,0.00,''),(25,24,5,1,30.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,635.59,0.00,''),(26,25,5,1,30.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,635.59,0.00,''),(27,26,5,1,30.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,635.59,0.00,''),(28,27,5,1,30.00,'01',25.00,3.81,3.81,'10','1000','IGV','VAT',3.81,21.18644,635.59,0.00,''),(29,28,9,1,5.00,'01',15.00,11.44,11.40,'10','1000','IGV','VAT',2.29,12.71186,63.56,0.00,''),(30,29,9,1,5.00,'01',15.00,11.44,11.44,'10','1000','IGV','VAT',2.29,12.71186,63.56,0.00,''),(31,30,9,1,5.00,'01',15.00,2.29,2.29,'10','1000','IGV','VAT',2.29,12.71186,63.56,0.00,''),(32,31,9,1,5.00,'01',15.00,11.44,11.44,'10','1000','IGV','VAT',11.44,12.71186,63.56,0.00,''),(33,32,13,1,6.00,'01',200.00,183.05,183.05,'10','1000','IGV','VAT',183.05,169.49153,1016.95,0.00,''),(34,33,13,1,3.00,'01',200.00,91.53,91.53,'10','1000','IGV','VAT',91.53,169.49153,508.47,0.00,''),(35,34,13,1,3.00,'01',200.00,91.53,91.53,'10','1000','IGV','VAT',91.53,169.49153,508.47,0.00,''),(36,35,13,1,3.00,'01',200.00,91.53,91.53,'10','1000','IGV','VAT',91.53,169.49153,508.47,0.00,''),(37,36,13,1,3.00,'01',200.00,91.53,91.53,'10','1000','IGV','VAT',91.53,169.49153,508.47,0.00,''),(38,37,9,1,3.00,'01',15.00,6.86,6.86,'10','1000','IGV','VAT',6.86,12.71186,38.14,0.00,''),(39,38,9,1,3.00,'01',15.00,6.86,6.86,'10','1000','IGV','VAT',6.86,12.71186,38.14,0.00,''),(40,39,9,1,3.00,'01',15.00,6.86,6.86,'10','1000','IGV','VAT',6.86,12.71186,38.14,0.00,''),(41,40,9,1,20.00,'01',18.00,54.92,54.92,'10','1000','IGV','VAT',54.92,15.25424,305.08,0.00,''),(42,41,13,1,1.00,'01',200.00,30.51,30.51,'10','1000','IGV','VAT',30.51,169.49153,169.49,0.00,''),(43,42,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,''),(44,43,4,1,10.00,'01',10.00,15.25,15.25,'10','1000','IGV','VAT',1.53,8.47458,84.75,0.00,''),(45,44,9,1,1.00,'01',15.00,2.29,2.29,'10','1000','IGV','VAT',2.29,12.71186,12.71,0.00,''),(46,45,9,1,20.00,'01',18.00,54.92,54.92,'10','1000','IGV','VAT',54.92,15.25424,305.08,0.00,''),(47,46,13,1,1.00,'01',200.00,30.51,30.51,'10','1000','IGV','VAT',30.51,169.49153,169.49,0.00,''),(48,47,4,1,1.00,'01',10.00,1.53,1.53,'10','1000','IGV','VAT',1.53,8.47458,8.47,0.00,'');
/*!40000 ALTER TABLE `detalle_fac_art` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_fac_art_ser`
--

DROP TABLE IF EXISTS `detalle_fac_art_ser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_fac_art_ser` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `numero_orden_item_33` int(11) NOT NULL,
  `cantidad_item_12` float(12,2) NOT NULL,
  `codigo_precio_15_1` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `precio_venta_item_15_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_16_1` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_16_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_16_3` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_item_16_4` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_item_16_5` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_item_16_6` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `igv_item` float(12,2) NOT NULL,
  `valor_uni_item_14` float(12,5) NOT NULL,
  `valor_venta_item_21` float(12,2) NOT NULL,
  `dcto_item` float(12,2) DEFAULT NULL,
  `descdet` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `fk_detalle_fact_idx` (`idfactura`),
  KEY `fk_detalle_prod_idx` (`idarticulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_fac_art_ser`
--

LOCK TABLES `detalle_fac_art_ser` WRITE;
/*!40000 ALTER TABLE `detalle_fac_art_ser` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_fac_art_ser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_notacd_art`
--

DROP TABLE IF EXISTS `detalle_notacd_art`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_notacd_art` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idnotacd` int(11) DEFAULT NULL,
  `idarticulo` int(11) DEFAULT NULL,
  `nro_orden` int(11) DEFAULT NULL,
  `cantidad` float(12,2) NOT NULL,
  `precio_venta` float(12,2) NOT NULL,
  `igv` float(12,2) NOT NULL,
  `valor_unitario` float(12,5) NOT NULL,
  `valor_venta` float(12,2) NOT NULL,
  `aigv` varchar(20) DEFAULT NULL,
  `codtrib` varchar(20) DEFAULT NULL,
  `nomtrib` varchar(20) DEFAULT NULL,
  `coditrib` varchar(20) DEFAULT NULL,
  `numorden` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `idnotacd` (`idnotacd`),
  KEY `idarticulo` (`idarticulo`),
  CONSTRAINT `detalle_notacd_art_ibfk_1` FOREIGN KEY (`idnotacd`) REFERENCES `notacd` (`idnota`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_notacd_art`
--

LOCK TABLES `detalle_notacd_art` WRITE;
/*!40000 ALTER TABLE `detalle_notacd_art` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_notacd_art` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_notapedido_producto`
--

DROP TABLE IF EXISTS `detalle_notapedido_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_notapedido_producto` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idboleta` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `numero_orden_item_29` int(11) DEFAULT NULL,
  `cantidad_item_12` float(12,2) NOT NULL,
  `codigo_precio_14_1` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `precio_uni_item_14_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_monto_27_1` float(12,2) DEFAULT NULL,
  `afectacion_igv_item_monto_27_2` float(12,2) DEFAULT NULL,
  `afectacion_igv_3` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_4` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_5` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afectacion_igv_6` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `igv_item` float(12,2) NOT NULL,
  `valor_uni_item_31` float(12,5) NOT NULL,
  `valor_venta_item_32` float(12,2) NOT NULL,
  `dcto_item` float(12,2) DEFAULT NULL,
  `descdet` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iddetalle`),
  KEY `fk_detalle_boleta_idx` (`idboleta`),
  KEY `fk_detalle_producto_idx` (`idarticulo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_notapedido_producto`
--

LOCK TABLES `detalle_notapedido_producto` WRITE;
/*!40000 ALTER TABLE `detalle_notapedido_producto` DISABLE KEYS */;
INSERT INTO `detalle_notapedido_producto` VALUES (1,1,9,1,2.00,'01',15.00,30.00,30.00,'10','1000','IGV','VAT',0.00,30.00000,30.00,NULL,'');
/*!40000 ALTER TABLE `detalle_notapedido_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_ordenservicio_articulo`
--

DROP TABLE IF EXISTS `detalle_ordenservicio_articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_ordenservicio_articulo` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idorden` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` float(12,2) NOT NULL,
  `valorcosto` float(12,5) NOT NULL,
  `totalunitario` float(12,2) NOT NULL,
  PRIMARY KEY (`iddetalle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_ordenservicio_articulo`
--

LOCK TABLES `detalle_ordenservicio_articulo` WRITE;
/*!40000 ALTER TABLE `detalle_ordenservicio_articulo` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_ordenservicio_articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_plato_pedido`
--

DROP TABLE IF EXISTS `detalle_plato_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_plato_pedido` (
  `iddetalle` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idplato` int(11) NOT NULL,
  `idpedido` int(11) NOT NULL,
  `norden` int(10) DEFAULT NULL,
  `cantidad` float(14,2) DEFAULT NULL,
  `precioitem` float(14,2) DEFAULT NULL,
  `valoruniitem` float(14,4) DEFAULT NULL,
  `igvitem` float(14,2) DEFAULT NULL,
  `valorventaitem` float(14,2) DEFAULT NULL,
  `igvvaloritem` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`iddetalle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_plato_pedido`
--

LOCK TABLES `detalle_plato_pedido` WRITE;
/*!40000 ALTER TABLE `detalle_plato_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_plato_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_servicio_cotizacion`
--

DROP TABLE IF EXISTS `detalle_servicio_cotizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_servicio_cotizacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcotizacion` int(11) NOT NULL,
  `iditem` int(11) NOT NULL,
  `codigo` char(20) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` float(14,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_servicio_cotizacion`
--

LOCK TABLES `detalle_servicio_cotizacion` WRITE;
/*!40000 ALTER TABLE `detalle_servicio_cotizacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_servicio_cotizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_tablaxml_comprobante`
--

DROP TABLE IF EXISTS `detalle_tablaxml_comprobante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_tablaxml_comprobante` (
  `iddetalle` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idtablaxml` int(11) NOT NULL,
  `idcomprobante` int(11) NOT NULL,
  `tipocomprobante` char(4) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`iddetalle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_tablaxml_comprobante`
--

LOCK TABLES `detalle_tablaxml_comprobante` WRITE;
/*!40000 ALTER TABLE `detalle_tablaxml_comprobante` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_tablaxml_comprobante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_usuario_numeracion`
--

DROP TABLE IF EXISTS `detalle_usuario_numeracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_usuario_numeracion` (
  `iddetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `idnumeracion` int(11) NOT NULL,
  PRIMARY KEY (`iddetalle`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_usuario_numeracion`
--

LOCK TABLES `detalle_usuario_numeracion` WRITE;
/*!40000 ALTER TABLE `detalle_usuario_numeracion` DISABLE KEYS */;
INSERT INTO `detalle_usuario_numeracion` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7);
/*!40000 ALTER TABLE `detalle_usuario_numeracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distrito`
--

DROP TABLE IF EXISTS `distrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distrito` (
  `iddistrito` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `codigo_postal` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idciudad` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddistrito`),
  KEY `fk_distrito_ciudad_idx` (`idciudad`),
  CONSTRAINT `fk_distrito_ciudad` FOREIGN KEY (`idciudad`) REFERENCES `ciudad` (`idciudad`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distrito`
--

LOCK TABLES `distrito` WRITE;
/*!40000 ALTER TABLE `distrito` DISABLE KEYS */;
INSERT INTO `distrito` VALUES (1,'BAGUA GRANDE',NULL,1),(2,'CHACHAPOYAS',NULL,2),(3,'CHIMBOTE',NULL,3),(4,'COISHCO',NULL,3),(5,'NUEVO CHIMBOTE',NULL,3),(6,'HUARAZ',NULL,4),(7,'INDEPENDENCIA',NULL,4),(8,'CASMA',NULL,5),(9,'ABANCAY',NULL,6),(10,'TAMBURCO',NULL,6),(11,'ANDAHUAYLAS',NULL,7),(12,'SAN JERÓNIMO',NULL,7),(13,'TALAVERA',NULL,7),(14,'AREQUIPA',NULL,8),(15,'ALTO SELVA ALEGRE',NULL,8),(16,'CAYMA',NULL,8),(17,'CERRO COLORADO',NULL,8),(18,'JACOBO HUNTER',NULL,8),(19,'MARIANO MELGAR',NULL,8),(20,'MIRAFLORES',NULL,8),(21,'PAUCARPATA',NULL,8),(22,'SABANDÍA',NULL,8),(23,'SACHACA',NULL,8),(24,'SOCABAYA',NULL,8),(25,'TIABYA',NULL,8),(26,'YANAHUARA',NULL,8),(27,'JOSE LUIS BUSTAMANTE',NULL,8),(28,'CAMANÁ',NULL,9),(29,'JOSE MARÍA QUIMPER',NULL,9),(30,'SAMUEL PASTOR',NULL,9),(31,'MOLLENDO',NULL,10),(32,'AYACUCHO',NULL,11),(33,'CARMEN ALTO',NULL,11),(34,'SAN JUAN BAUTISTA',NULL,11),(35,'JESUS NAZARENO',NULL,11),(36,'HUANTA',NULL,12),(37,'CAJAMARCA',NULL,13),(38,'LOS BAÑOS DEL INCA',NULL,13),(39,'JAÉN',NULL,14),(40,'CUSCO',NULL,15),(41,'SAN JERÓNIMO',NULL,15),(42,'SAN SEBASTIÁN',NULL,15),(43,'SANTIAGO',NULL,15),(44,'WANCHAQ',NULL,15),(45,'SICUANI',NULL,16),(46,'SANTA ANA',NULL,17),(47,'ESPINAR',NULL,18),(48,'HUANCAVELICA',NULL,19),(49,'ASCENCIÓN',NULL,19),(50,'HUÁNUCO',NULL,20),(51,'AMARILIS',NULL,20),(52,'PILLCO MARCA',NULL,20),(53,'RUPA-RUPA',NULL,21),(54,'ICA',NULL,22),(55,'LA TINGUIÑA',NULL,22),(56,'PARCONA',NULL,22),(57,'SUBTANJALLA',NULL,2),(58,'CHINCHA ALTA',NULL,23),(59,'GROCIO PRADO',NULL,23),(60,'PUEBLO NUEVO',NULL,23),(61,'SUNAMPE',NULL,23),(62,'PISCO',NULL,24),(63,'SAN ANDRÉS',NULL,24),(64,'SAN CLEMENTE',NULL,24),(65,'TÚPAC AMARU INCA',NULL,24),(66,'NAZCA',NULL,25),(67,'VISTA ALEGRE',NULL,25),(68,'HUANCAYO',NULL,26),(69,'CHILCA',NULL,26),(70,'EL TAMBO',NULL,26),(71,'TARMA',NULL,27),(72,'LA OROYA',NULL,28),(73,'SANTA ROSA DE SACCO',NULL,28),(74,'JAUJA',NULL,29),(75,'TRUJILLO',NULL,30),(76,'EL PORVENIR',NULL,3),(77,'FLORENCIA DE MORA',NULL,30),(78,'LA ESPERANZA',NULL,30),(79,'VICTOR LARCO HERRERA',NULL,30),(80,'CHEPÉN',NULL,31),(81,'GUADALUPE',NULL,32),(82,'CASA GRANDE',NULL,33),(83,'PACASMAYO',NULL,34),(84,'HUAMACHUCO',NULL,35),(85,'LAREDO',NULL,36),(86,'MOCHE',NULL,37),(87,'CHICLAYO',NULL,38),(88,'JOSE LEONARDO ORTIZ',NULL,38),(89,'LA VICTORIA',NULL,38),(90,'PIMENTEL',NULL,38),(91,'LAMBAYEQUE',NULL,39),(92,'FERREÑAFE',NULL,40),(93,'PUEBLO NUEVO',NULL,40),(94,'TUMAN',NULL,41),(95,'MONSEFU',NULL,42),(96,'LIMA',NULL,43),(97,'ANCÓN',NULL,43),(98,'ATE',NULL,43),(99,'BARRANCO',NULL,43),(100,'BREÑA',NULL,43),(101,'CARABAYLLO',NULL,43),(102,'CHACLACAYO',NULL,43),(103,'CHORRILLOS',NULL,43),(104,'CIENEGUILLA',NULL,43),(105,'COMAS',NULL,43),(106,'EL AGUSTINO',NULL,43),(107,'INDEPENDENCIA',NULL,43),(108,'JESÚS MARIA',NULL,43),(109,'LA MOLINA',NULL,43),(110,'LA VICTORIA',NULL,43),(111,'LINCE',NULL,43),(112,'LOS OLIVOS',NULL,43),(113,'LURIGANCHO',NULL,43),(114,'LURIN',NULL,43),(115,'MAGDALENA DEL MAR',NULL,43),(116,'MAGDALENA VIEJA',NULL,43),(117,'MIRAFLORES',NULL,43),(118,'PACHACAMAC',NULL,43),(119,'PUCUSANA',NULL,43),(120,'PUENTE PIEDRA',NULL,43),(121,'PUNTA HERMOSA',NULL,43),(122,'PUNTA NEGRA',NULL,43),(123,'RÍMAC',NULL,43),(124,'SAN BARTOLO',NULL,43),(125,'SAN BORJA',NULL,43),(126,'SAN ISIDRO',NULL,43),(127,'SAN JUAN DE LURIGANCHO',NULL,43),(128,'SAN JUAN DE MIRAFLORES',NULL,43),(129,'SAN LUIS',NULL,43),(130,'SAN MARTÍN DE PORRES',NULL,43),(131,'SAN MIGUEL',NULL,43),(132,'SANTA ANITA',NULL,43),(133,'SANTA MARIA DEL MAR',NULL,43),(134,'SANTA ROSA',NULL,43),(135,'SANTIAGO DE SURCO',NULL,43),(136,'SURQUILLO',NULL,43),(137,'VILLA EL SALVADOR',NULL,43),(138,'VILLA MARÍA DEL TRIUNFO',NULL,43),(139,'CALLAO',NULL,43),(140,'BELLAVISTA',NULL,43),(141,'CARMEN DE LA LEGUA REYNOSO',NULL,43),(142,'LA PERLA',NULL,43),(143,'LA PUNTA',NULL,43),(144,'VENTANILLA',NULL,43),(145,'HUACHO',NULL,44),(146,'CALETA DE CARQUÍN',NULL,44),(147,'HUALMAY',NULL,44),(148,'HUARAL',NULL,45),(149,'SAN VICENTE DE CAÑETA IMPERIAL',NULL,46),(150,'BARRANCA',NULL,47),(151,'HUAURA',NULL,48),(152,'SANTA MARÍA',NULL,48),(153,'PARAMONGA',NULL,49),(154,'PATIVILCA',NULL,49),(155,'CHANCAY',NULL,50),(156,'MALA',NULL,51),(157,'NUEVO IMPERIAL',NULL,51),(158,'SUPE',NULL,52),(159,'SUPE PUERTO',NULL,52),(160,'IQUITOS',NULL,53),(161,'PUNCHANA',NULL,53),(162,'BELÉN',NULL,53),(163,'SAN JUAN BAUTISTA',NULL,53),(164,'YURIMAGUAS',NULL,54),(165,'TAMBOPATA',NULL,55),(166,'ILO',NULL,56),(167,'MOQUEGUA',NULL,57),(168,'SAMEGUA',NULL,57),(169,'CHAUPIMARCA',NULL,58),(170,'SIMON BOLIVAR',NULL,58),(171,'YANACANCHA',NULL,58),(172,'PIURA',NULL,59),(173,'CASTILLA',NULL,59),(174,'SULLANA',NULL,60),(175,'BELLAVISTA',NULL,60),(176,'PARINAS',NULL,61),(177,'CATACAOS',NULL,62),(178,'PAITA',NULL,63),(179,'CHULUCANAS',NULL,64),(180,'SECHURA',NULL,65),(181,'JULIACA',NULL,66),(182,'PUNO',NULL,67),(183,'AYAVIRI',NULL,68),(184,'ILAVE',NULL,69),(185,'TARAPOTO',NULL,70),(186,'LA BANDA DE SHILCAYO',NULL,70),(187,'MORALES',NULL,70),(188,'MOYOBAMBA',NULL,71),(189,'RIOJA',NULL,72),(190,'TACNA',NULL,73),(191,'ALTO DE ALIANZA',NULL,73),(192,'CIUDAD NUEVA',NULL,73),(193,'POCOLLAY',NULL,73),(194,'CORONEL GREGORIO ALBARRACIN LANCHIPA',NULL,73),(195,'TUMBES',NULL,74),(196,'CALLARIA',NULL,75),(197,'YARINACHOCHA',NULL,75),(198,'S/D','SCP',76);
/*!40000 ALTER TABLE `distrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doccobranza`
--

DROP TABLE IF EXISTS `doccobranza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doccobranza` (
  `idccobranza` int(11) NOT NULL AUTO_INCREMENT,
  `idempresa` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `condicion` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `fechaemision` datetime NOT NULL,
  `serienumero` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `tarifa` float(14,2) NOT NULL,
  `neta` float(14,2) NOT NULL,
  `igv` float(14,2) NOT NULL,
  `otros` float(14,2) NOT NULL,
  `deduccion` float(14,2) NOT NULL,
  `total` float(14,2) NOT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `tcambio` float(14,2) NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `tipo_moneda` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipodoccobranza` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nfactura` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idccobranza`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doccobranza`
--

LOCK TABLES `doccobranza` WRITE;
/*!40000 ALTER TABLE `doccobranza` DISABLE KEYS */;
INSERT INTO `doccobranza` VALUES (1,1,1,3,'contado','2020-07-07 15:25:04','DC01-1',0.00,38.14,6.86,0.00,0.00,45.00,'hjghjgj',0.00,1,'PEN','servicio',NULL),(2,1,1,3,'contado','2020-08-06 09:53:37','DC01-2',0.00,72.03,12.97,0.00,0.00,85.00,'',3.35,1,'USD','servicio',NULL);
/*!40000 ALTER TABLE `doccobranza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `idempresa` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_razon_social` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `nombre_comercial` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `domicilio_fiscal` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `numero_ruc` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `web` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `webconsul` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nresolucion` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ubigueo` char(5) COLLATE utf8_unicode_ci DEFAULT '0000',
  `codubigueo` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudad` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distrito` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interior` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigopais` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuenta1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banco1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuenta2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banco2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuenta3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banco3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuenta4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banco4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuentacci1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuentacci2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuentacci3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cuentacci4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idempresa`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES (1,'TECNOLOGOS PERU EIRL','TECNOLOGOS PERU EIRL','AV. 10 DE JUNIO TORRE 3 NRO. 1020 DPTO. 601 URB. MIGUEL GRAU LIMA - LIMA - SAN MARTIN DE PORRES','20603504969','966461459','.','eduardoaroni84@gmail.com','www.tecnologosperu.com','-','1594139535.png',NULL,'0000','0000','lima','la victoria','la victoria','PE','01111548787877','Banco Bbva','55555555562436','Banco Interbank','23423423456','Banco Scotiaban','888845454','Nanco Pichincha','1111111111111','222222222222222','333333','54547787878');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enviocorreo`
--

DROP TABLE IF EXISTS `enviocorreo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enviocorreo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_documento` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cliente` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comprobante` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_envio` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enviocorreo`
--

LOCK TABLES `enviocorreo` WRITE;
/*!40000 ALTER TABLE `enviocorreo` DISABLE KEYS */;
INSERT INTO `enviocorreo` VALUES (1,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','0','F001-19','2020-07-11 11:33:28'),(2,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','0','F001-19','2020-07-11 11:33:48'),(3,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','0','F001-19','2020-07-11 11:33:56'),(4,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','0','F001-19','2020-07-11 11:36:24'),(5,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','tecnologosperu@gmail.com','F001-19','2020-07-11 11:37:24'),(6,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','tecnologosperu@gmail.com','F001-19','2020-07-11 11:38:56'),(7,'20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','tecnologosperu@gmail.com','F001-19','2020-07-11 11:53:43'),(8,NULL,NULL,NULL,NULL,'2020-08-11 09:26:14');
/*!40000 ALTER TABLE `enviocorreo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura`
--

DROP TABLE IF EXISTS `factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura` (
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `fecha_emision_01` datetime NOT NULL,
  `firmadigital_02` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `idempresa` int(11) NOT NULL,
  `tipo_documento_07` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numeracion_08` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `idcliente` int(11) NOT NULL,
  `total_operaciones_gravadas_codigo_18_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_operaciones_gravadas_monto_18_2` float(12,2) DEFAULT NULL,
  `sumatoria_igv_22_1` float(12,2) NOT NULL,
  `sumatoria_igv_22_2` float(12,2) DEFAULT NULL,
  `codigo_tributo_22_3` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_tributo_22_4` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_internacional_22_5` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `importe_total_venta_27` float(12,2) NOT NULL,
  `tipo_documento_29_1` int(11) DEFAULT NULL,
  `guia_remision_29_2` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_leyenda_31_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion_leyenda_31_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_ubl_36` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `version_estructura_37` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_moneda_28` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `tasa_igv` float(12,2) DEFAULT '0.18',
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `tipodocuCliente` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rucCliente` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RazonSocial` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idguia` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `comentario_baja` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdescuento` float(12,2) DEFAULT NULL,
  `vendedorsitio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcambio` float(14,2) DEFAULT NULL,
  `tipopago` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nroreferencia` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ipagado` float(14,2) DEFAULT NULL,
  `saldo` float(14,2) DEFAULT NULL,
  `CodigoRptaSunat` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DetalleSunat` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icbper` float(14,2) DEFAULT NULL,
  `tipofactura` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocompra` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `numeracion_08` (`numeracion_08`),
  KEY `fk_factura_empresa_idx` (`idempresa`),
  KEY `fk_factura_usuario_idx` (`idusuario`),
  KEY `fk_factura_persona_idx` (`idcliente`),
  CONSTRAINT `fk_factura_empresa` FOREIGN KEY (`idempresa`) REFERENCES `empresa` (`idempresa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_factura_persona` FOREIGN KEY (`idcliente`) REFERENCES `persona` (`idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_factura_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura`
--

LOCK TABLES `factura` WRITE;
/*!40000 ALTER TABLE `factura` DISABLE KEYS */;
INSERT INTO `factura` VALUES (1,1,'2020-06-26 10:49:17','',1,'01','F001-1',2,'1001',16.95,3.05,3.05,'1000','IGV','VAT',20.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,4,'6','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'productos',NULL),(2,1,'2020-06-26 10:57:56','',1,'01','F001-2',2,'1001',42.37,7.63,7.63,'1000','IGV','VAT',50.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-2, ha sido aceptada',0.00,'productos',NULL),(3,1,'2020-06-29 09:39:55','',1,'01','F001-3',2,'1001',84.75,15.25,15.25,'1000','IGV','VAT',100.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,1,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'Emitido',0.00,'productos',NULL),(4,1,'2020-06-30 09:43:04','',1,'01','F001-4',2,'1001',211.86,38.14,38.14,'1000','IGV','VAT',250.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,4,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'productos',NULL),(5,1,'2020-06-30 17:13:09','',1,'01','F001-5',2,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-5, ha sido aceptada',0.00,'productos',NULL),(6,1,'2020-07-01 10:16:50','',1,'01','F001-6',2,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,4,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'productos',NULL),(7,1,'2020-07-02 11:35:13','',1,'01','F001-7',2,'1001',29.66,5.34,5.34,'1000','IGV','VAT',35.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-7, ha sido aceptada',0.00,'productos',NULL),(8,1,'2020-07-02 11:48:27','',1,'01','F001-8',2,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','USD',0.18,5,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',3.91,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-8, ha sido aceptada',0.00,'productos',NULL),(9,1,'2020-07-07 15:25:04','',1,'01','F001-9',3,'1001',38.14,6.86,6.86,'1000','IGV','VAT',45.00,0,'-','1000','-','2.0','1.0','PEN',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(10,1,'2020-07-10 09:44:47','',1,'01','F001-10',3,'1001',42.37,7.63,7.63,'1000','IGV','VAT',50.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 09:48:55','eafsdf',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'3','XML firmado',0.00,'productos',NULL),(11,1,'2020-07-10 09:45:02','',1,'01','F001-11',3,'1001',42.37,7.63,7.63,'1000','IGV','VAT',50.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 09:45:13','fafasf',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'3','XML firmado',0.00,'productos',NULL),(12,1,'2020-07-10 09:50:21','',1,'01','F001-12',3,'1001',42.37,7.63,7.63,'1000','IGV','VAT',50.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,1,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'Emitido',0.00,'productos',NULL),(13,1,'2020-07-10 10:02:43','',1,'01','F001-13',3,'1001',42.37,7.63,7.63,'1000','IGV','VAT',50.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 10:02:55','dfdfasgdfgd',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'3','XML firmado',0.00,'productos',NULL),(14,1,'2020-07-10 10:04:40','',1,'01','F001-14',3,'1001',16.95,3.05,3.05,'1000','IGV','VAT',20.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 10:04:48','asdasd',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'3','XML firmado',0.00,'productos',NULL),(15,1,'2020-07-10 10:12:25','',1,'01','F001-15',3,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 10:12:29','sdfsdfsdf',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'3','XML firmado',0.00,'productos',NULL),(16,1,'2020-07-10 10:34:27','',1,'01','F001-16',3,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 10:34:31','sdfsdfsdf',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-16, ha sido aceptada',0.00,'productos',NULL),(17,1,'2020-07-10 10:50:59','',1,'01','F001-17',3,'1001',21.19,3.81,3.81,'1000','IGV','VAT',25.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,3,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,'2020-07-10 10:51:12','.',0.00,'',0.00,'EFECTIVO','',0.00,0.00,'3','C/Baja',0.00,'productos',NULL),(18,1,'2020-07-10 11:22:05','',1,'01','F001-18',2,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-18, ha sido aceptada',0.00,'productos',NULL),(19,1,'2020-07-11 11:33:10','',1,'01','F001-19',3,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-19, ha sido aceptada',0.00,'productos',NULL),(20,1,'2020-07-27 09:44:29','',1,'01','F001-20',3,'1001',84.75,15.25,15.25,'1000','IGV','VAT',100.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,1,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'Emitido',0.00,'productos',NULL),(21,1,'2020-08-05 15:46:12','',1,'01','F001-21',3,'1001',12.71,2.29,2.29,'1000','IGV','VAT',15.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-21, ha sido aceptada',0.00,'productos',NULL),(22,1,'2020-08-05 15:48:28','',1,'01','F001-22',3,'1001',169.49,30.51,30.51,'1000','IGV','VAT',200.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-22, ha sido aceptada',0.00,'productos',NULL),(23,1,'2020-08-05 16:22:04','',1,'01','F001-23',3,'1001',0.00,0.00,0.00,'1000','IGV','VAT',0.00,0,'-','1000','-','2.0','1.0','',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.25,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(24,1,'2020-08-05 16:22:04','',1,'01','F001-24',3,'1001',635.59,114.41,114.41,'1000','IGV','VAT',750.00,0,'-','1000','-','2.0','1.0','',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.25,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(25,1,'2020-08-05 16:22:04','',1,'01','F001-25',3,'1001',635.59,114.41,114.41,'1000','IGV','VAT',750.00,0,'-','1000','-','2.0','1.0','PEN',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.25,'EFECTIVO','234235235235',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(26,1,'2020-08-06 16:22:04','',1,'01','F001-26',3,'1001',635.59,114.41,114.41,'1000','IGV','VAT',750.00,0,'-','1000','-','2.0','1.0','',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.25,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(27,1,'2020-08-06 16:22:04','',1,'01','F001-27',3,'1001',635.59,114.41,114.41,'1000','IGV','VAT',750.00,0,'-','1000','-','2.0','1.0','USD',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.25,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(28,1,'2020-08-06 16:51:30','',1,'01','F001-28',3,'1001',63.56,11.44,11.44,'1000','IGV','VAT',75.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-28, ha sido aceptada',0.00,'',NULL),(29,1,'2020-08-06 16:53:24','',1,'01','F001-29',3,'1001',63.56,11.44,11.44,'1000','IGV','VAT',75.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-29, ha sido aceptada',0.00,'productos',NULL),(30,1,'2020-08-06 16:51:30','',1,'01','F001-30',3,'1001',63.56,11.44,11.44,'1000','IGV','VAT',75.00,0,'-','1000','-','2.0','1.0','PEN',0.18,4,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'XML firmado',0.00,'',NULL),(31,1,'2020-08-06 16:51:30','',1,'01','F001-31',3,'1001',63.56,11.44,11.44,'1000','IGV','VAT',75.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-31, ha sido aceptada',0.00,'',NULL),(32,1,'2020-08-06 17:33:16','',1,'01','F001-32',3,'1001',1016.95,183.05,183.05,'1000','IGV','VAT',1200.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-32, ha sido aceptada',0.00,'',NULL),(33,1,'2020-08-06 17:35:53','',1,'01','F001-33',3,'1001',508.47,91.53,91.53,'1000','IGV','VAT',600.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-33, ha sido aceptada',0.00,'',NULL),(34,1,'2020-08-06 17:35:53','',1,'01','F001-34',3,'1001',508.47,91.53,91.53,'1000','IGV','VAT',600.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-34, ha sido aceptada',0.00,'',NULL),(35,1,'2020-08-06 17:35:53','',1,'01','F001-35',3,'1001',508.47,91.53,91.53,'1000','IGV','VAT',600.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-35, ha sido aceptada',0.00,'',NULL),(36,1,'2020-08-06 17:35:53','',1,'01','F001-36',3,'1001',508.47,91.53,91.53,'1000','IGV','VAT',600.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-36, ha sido aceptada',0.00,'',NULL),(37,1,'2020-08-06 17:47:34','',1,'01','F001-37',3,'1001',38.14,6.86,6.86,'1000','IGV','VAT',45.00,0,'-','1000','-','2.0','1.0','USD',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.55,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-37, ha sido aceptada',0.00,'',NULL),(38,1,'2020-08-10 17:47:34','',1,'01','F001-38',3,'1001',38.14,6.86,6.86,'1000','IGV','VAT',45.00,0,'-','1000','-','2.0','1.0','USD',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.55,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-38, ha sido aceptada',0.00,'',NULL),(39,1,'2020-08-10 17:47:34','',1,'01','F001-39',3,'1001',38.14,6.86,6.86,'1000','IGV','VAT',45.00,0,'-','1000','-','2.0','1.0','USD',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',3.55,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-39, ha sido aceptada',0.00,'',NULL),(40,1,'2020-08-10 12:00:43','',1,'01','F001-40',3,'1001',305.08,54.92,54.92,'1000','IGV','VAT',360.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-40, ha sido aceptada',0.00,'',NULL),(41,1,'2020-08-10 12:11:25','',1,'01','F001-41',3,'1001',169.49,30.51,30.51,'1000','IGV','VAT',200.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-41, ha sido aceptada',0.00,'productos',NULL),(42,1,'2020-08-10 15:39:37','',1,'01','F001-42',3,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-42, ha sido aceptada',0.00,'productos',NULL),(43,1,'2020-08-10 15:39:54','',1,'01','F001-43',3,'1001',84.75,15.25,15.25,'1000','IGV','VAT',100.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-43, ha sido aceptada',0.00,'productos',NULL),(44,1,'2020-08-10 15:41:06','',1,'01','F001-44',3,'1001',12.71,2.29,2.29,'1000','IGV','VAT',15.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,5,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,'0','La Factura numero F001-44, ha sido aceptada',0.00,'productos',NULL),(45,1,'2020-08-11 12:00:43','',1,'01','F001-45',3,'1001',305.08,54.92,54.92,'1000','IGV','VAT',360.00,0,'-','1000','-','2.0','1.0','PEN',0.18,5,'6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'DEPÓSITO','222451244454',0.00,0.00,'0','La Factura numero F001-45, ha sido aceptada',0.00,'',NULL),(46,1,'2020-08-12 09:56:01','',1,'01','F001-46',3,'1001',169.49,30.51,30.51,'1000','IGV','VAT',200.00,0,'GR01-1','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,1,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',1,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'Emitido',0.00,'productos',NULL),(47,1,'2020-08-14 09:05:04','',1,'01','F001-47',3,'1001',8.47,1.53,1.53,'1000','IGV','VAT',10.00,0,'','1000','DESCRIPCION DE LEYENDA','2.0','1.0','PEN',0.18,1,' ','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.',NULL,NULL,NULL,0.00,'',0.00,'EFECTIVO','',0.00,0.00,NULL,'Emitido',0.00,'productos',NULL);
/*!40000 ALTER TABLE `factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturaservicio`
--

DROP TABLE IF EXISTS `facturaservicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturaservicio` (
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `fecha_emision_01` datetime NOT NULL,
  `firmadigital_02` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `idempresa` int(11) NOT NULL,
  `tipo_documento_07` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numeracion_08` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `idcliente` int(11) NOT NULL,
  `total_operaciones_gravadas_codigo_18_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_operaciones_gravadas_monto_18_2` float(12,2) DEFAULT NULL,
  `sumatoria_igv_22_1` float(12,2) NOT NULL,
  `sumatoria_igv_22_2` float(12,2) DEFAULT NULL,
  `codigo_tributo_22_3` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_tributo_22_4` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_internacional_22_5` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `importe_total_venta_27` float(12,2) NOT NULL,
  `tipo_documento_29_1` int(11) DEFAULT NULL,
  `guia_remision_29_2` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_leyenda_31_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion_leyenda_31_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_ubl_36` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `version_estructura_37` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_moneda_28` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `tasa_igv` float(12,2) DEFAULT '0.18',
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `tipodocuCliente` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rucCliente` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RazonSocial` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idguia` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `comentario_baja` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdescuento` float(12,2) DEFAULT NULL,
  `vendedorsitio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icbper` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `numeracion_08` (`numeracion_08`),
  KEY `fk_factura_empresa_idx` (`idempresa`),
  KEY `fk_factura_usuario_idx` (`idusuario`),
  KEY `fk_factura_persona_idx` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturaservicio`
--

LOCK TABLES `facturaservicio` WRITE;
/*!40000 ALTER TABLE `facturaservicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturaservicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `familia`
--

DROP TABLE IF EXISTS `familia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `familia` (
  `idfamilia` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idfamilia`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `familia`
--

LOCK TABLES `familia` WRITE;
/*!40000 ALTER TABLE `familia` DISABLE KEYS */;
INSERT INTO `familia` VALUES (1,'NO UTLIZAR',1),(2,'NO DURADEROS',1),(3,'DURADEROS',1),(4,'DE SERVICIO',1),(5,'SERVICIO',1),(6,'BOLSAS',1);
/*!40000 ALTER TABLE `familia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftpparam`
--

DROP TABLE IF EXISTS `ftpparam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftpparam` (
  `ftphost` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ftpusername` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ftppassword` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftpparam`
--

LOCK TABLES `ftpparam` WRITE;
/*!40000 ALTER TABLE `ftpparam` DISABLE KEYS */;
/*!40000 ALTER TABLE `ftpparam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guia`
--

DROP TABLE IF EXISTS `guia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guia` (
  `idguia` int(11) NOT NULL AUTO_INCREMENT,
  `snumero` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pllegada` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destinatario` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nruc` char(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ppartida` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechat` date DEFAULT NULL,
  `ncomprobante` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocompra` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivo` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idcomprobante` int(11) NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `comprobante` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idempresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`idguia`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guia`
--

LOCK TABLES `guia` WRITE;
/*!40000 ALTER TABLE `guia` DISABLE KEYS */;
INSERT INTO `guia` VALUES (1,'GR01-1','PRO.HUANUCO NRO. 1416 URB. EL POVENIR (ESQUINA CON AV 28 DE JULIO) LIMA - LIMA - LA VICTORIA','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','20524682487','-','2020-08-12','F001-46','','venta',46,1,NULL,1);
/*!40000 ALTER TABLE `guia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingresocaja`
--

DROP TABLE IF EXISTS `ingresocaja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingresocaja` (
  `idingreso` int(11) NOT NULL AUTO_INCREMENT,
  `idcaja` int(11) NOT NULL,
  `concepto` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monto` float(14,2) DEFAULT NULL,
  `tipo` char(20) COLLATE utf8_unicode_ci DEFAULT 'INGRESO',
  PRIMARY KEY (`idingreso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingresocaja`
--

LOCK TABLES `ingresocaja` WRITE;
/*!40000 ALTER TABLE `ingresocaja` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingresocaja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kardex`
--

DROP TABLE IF EXISTS `kardex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kardex` (
  `idkardex` int(11) NOT NULL AUTO_INCREMENT,
  `idcomprobante` int(11) DEFAULT NULL,
  `idarticulo` int(11) DEFAULT NULL,
  `transaccion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `codigo` char(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `tipo_documento` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero_doc` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cantidad` float(14,2) DEFAULT NULL,
  `costo_1` float(12,5) DEFAULT NULL,
  `unidad_medida` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `saldo_final` float(14,2) DEFAULT NULL,
  `costo_2` float(14,2) DEFAULT NULL,
  `valor_final` float(14,2) DEFAULT NULL,
  `idempresa` int(11) DEFAULT NULL,
  `tcambio` float(14,5) DEFAULT NULL,
  `moneda` float(14,5) NOT NULL,
  PRIMARY KEY (`idkardex`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kardex`
--

LOCK TABLES `kardex` WRITE;
/*!40000 ALTER TABLE `kardex` DISABLE KEYS */;
INSERT INTO `kardex` VALUES (1,1,4,'VENTA','PAA1','2020-06-26 00:00:00','01','F001-1',2.00,8.47458,'NIU',998.00,5.00,4990.00,1,0.00000,0.00000),(2,2,4,'VENTA','PAA1','2020-06-26 00:00:00','01','F001-2',5.00,8.47458,'NIU',993.00,5.00,4965.00,1,0.00000,0.00000),(3,3,4,'VENTA','PAA1','2020-06-29 00:00:00','01','F001-3',10.00,8.47458,'NIU',983.00,5.00,4915.00,1,0.00000,0.00000),(4,1,4,'VENTA','PAA1','2020-06-29 00:00:00','03','B001-1',10.00,8.47458,'NIU',973.00,5.00,4865.00,1,0.00000,0.00000),(5,4,4,'VENTA','PAA1','2020-06-30 00:00:00','01','F001-4',5.00,8.47458,'NIU',968.00,5.00,4840.00,1,0.00000,0.00000),(6,4,5,'VENTA','CORE 2 DUO 1','2020-06-30 00:00:00','01','F001-4',8.00,21.18644,'NIU',592.00,5.00,2960.00,1,0.00000,0.00000),(7,5,4,'VENTA','PAA1','2020-06-30 00:00:00','01','F001-5',1.00,8.47458,'NIU',967.00,5.00,4835.00,1,0.00000,0.00000),(8,6,4,'VENTA','PAA1','2020-07-01 00:00:00','01','F001-6',1.00,8.47458,'NIU',966.00,5.00,4830.00,1,0.00000,0.00000),(9,2,4,'VENTA','PAA1','2020-07-01 00:00:00','03','B001-2',1.00,8.47458,'NIU',965.00,5.00,4825.00,1,0.00000,0.00000),(10,2,5,'VENTA','CORE 2 DUO 1','2020-07-01 00:00:00','03','B001-2',1.00,21.18644,'NIU',591.00,5.00,2955.00,1,0.00000,0.00000),(11,7,4,'VENTA','PAA1','2020-07-02 00:00:00','01','F001-7',1.00,8.47458,'NIU',964.00,5.00,4820.00,1,0.00000,0.00000),(12,7,5,'VENTA','CORE 2 DUO 1','2020-07-02 00:00:00','01','F001-7',1.00,21.18644,'NIU',590.00,5.00,2950.00,1,0.00000,0.00000),(13,8,4,'VENTA','PAA1','2020-07-02 00:00:00','01','F001-8',1.00,8.47458,'NIU',963.00,5.00,4815.00,1,3.91000,0.00000),(14,3,4,'VENTA','PAA1','2020-07-02 00:00:00','03','B001-3',1.00,8.47458,'NIU',962.00,5.00,4810.00,1,0.00000,0.00000),(15,4,4,'VENTA','PAA1','2020-07-03 00:00:00','03','B001-4',1.00,8.47458,'NIU',961.00,5.00,4805.00,1,0.00000,0.00000),(16,9,2,'VENTA','SR02','2020-07-07 00:00:00','01','F001-9',1.00,38.13559,'SU',999999.00,NULL,NULL,1,0.00000,0.00000),(17,10,4,'VENTA','PAA1','2020-07-10 00:00:00','01','F001-10',5.00,8.47458,'NIU',956.00,5.00,4780.00,1,0.00000,0.00000),(18,11,5,'VENTA','CORE 2 DUO 1','2020-07-10 00:00:00','01','F001-11',2.00,21.18644,'NIU',588.00,5.00,2940.00,1,0.00000,0.00000),(19,11,5,'ANULADO','CORE 2 DUO 1','2020-07-10 09:45:13','01','F001-11',2.00,21.18644,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(20,10,4,'ANULADO','PAA1','2020-07-10 09:48:55','01','F001-10',5.00,8.47458,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(21,12,5,'VENTA','CORE 2 DUO 1','2020-07-10 00:00:00','01','F001-12',2.00,21.18644,'NIU',588.00,5.00,2940.00,1,0.00000,0.00000),(22,13,4,'VENTA','PAA1','2020-07-10 00:00:00','01','F001-13',5.00,8.47458,'NIU',956.00,5.00,4780.00,1,0.00000,0.00000),(23,13,4,'ANULADO','PAA1','2020-07-10 10:02:55','01','F001-13',5.00,8.47458,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(24,14,4,'VENTA','PAA1','2020-07-10 00:00:00','01','F001-14',2.00,8.47458,'NIU',959.00,5.00,4795.00,1,0.00000,0.00000),(25,14,4,'ANULADO','PAA1','2020-07-10 10:04:48','01','F001-14',2.00,8.47458,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(26,15,4,'VENTA','PAA1','2020-07-10 00:00:00','01','F001-15',1.00,8.47458,'NIU',960.00,5.00,4800.00,1,0.00000,0.00000),(27,15,4,'ANULADO','PAA1','2020-07-10 10:12:29','01','F001-15',1.00,8.47458,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(28,16,4,'VENTA','PAA1','2020-07-10 00:00:00','01','F001-16',1.00,8.47458,'NIU',960.00,5.00,4800.00,1,0.00000,0.00000),(29,16,4,'ANULADO','PAA1','2020-07-10 10:34:31','01','F001-16',1.00,8.47458,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(30,17,5,'VENTA','CORE 2 DUO 1','2020-07-10 00:00:00','01','F001-17',1.00,21.18644,'NIU',587.00,5.00,2935.00,1,0.00000,0.00000),(31,17,5,'ANULADO','CORE 2 DUO 1','2020-07-10 10:51:12','01','F001-17',1.00,21.18644,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(32,18,4,'VENTA','PAA1','2020-07-10 00:00:00','01','F001-18',1.00,8.47458,'NIU',960.00,5.00,4800.00,1,0.00000,0.00000),(33,5,4,'VENTA','PAA1','2020-07-10 00:00:00','03','B001-5',1.00,8.47458,'NIU',959.00,5.00,4795.00,1,0.00000,0.00000),(34,5,4,'ANULADO','PAA1','2020-07-10 11:30:23','03','B001-5',1.00,8.47458,'NIU',0.00,0.00,0.00,NULL,NULL,0.00000),(35,6,5,'VENTA','CORE 2 DUO 1','2020-07-10 00:00:00','03','B001-6',1.00,21.18644,'NIU',587.00,5.00,2935.00,1,0.00000,0.00000),(36,19,4,'VENTA','PAA1','2020-07-11 00:00:00','01','F001-19',1.00,8.47458,'NIU',959.00,5.00,4795.00,1,0.00000,0.00000),(37,20,4,'VENTA','PAA1','2020-07-27 00:00:00','01','F001-20',10.00,8.47458,'NIU',949.00,5.00,4745.00,1,0.00000,0.00000),(38,7,9,'VENTA','LJ01','2020-07-31 00:00:00','03','B001-7',1.00,15.00000,'SU',999.00,10.00,9990.00,1,0.00000,0.00000),(39,21,9,'VENTA','LJ01','2020-08-05 00:00:00','01','F001-21',1.00,12.71186,'SU',998.00,10.00,9980.00,1,0.00000,0.00000),(40,22,13,'VENTA','VS012','2020-08-05 00:00:00','01','F001-22',1.00,169.49153,'SU',7999.00,25.00,199975.00,1,0.00000,0.00000),(41,1,9,'VENTA','LJ01','2020-08-05 00:00:00','50','NP01-1',2.00,15.00000,'SU',996.00,10.00,9960.00,NULL,NULL,0.00000),(42,24,5,'VENTA','CORE 2 DUO 1','2020-08-05 00:00:00','01','F001-24',30.00,21.18644,'NIU',557.00,5.00,2785.00,1,3.25000,0.00000),(43,25,5,'VENTA','CORE 2 DUO 1','2020-08-05 00:00:00','01','F001-25',30.00,21.18644,'NIU',527.00,5.00,2635.00,1,3.25000,0.00000),(44,26,5,'VENTA','CORE 2 DUO 1','2020-08-06 00:00:00','01','F001-26',30.00,21.18644,'NIU',497.00,5.00,2485.00,1,3.25000,0.00000),(45,27,5,'VENTA','CORE 2 DUO 1','2020-08-06 00:00:00','01','F001-27',30.00,21.18644,'NIU',467.00,5.00,2335.00,1,3.25000,0.00000),(46,28,9,'VENTA','LJ01','2020-08-06 00:00:00','01','F001-28',5.00,12.71186,'SU',991.00,10.00,9910.00,1,0.00000,0.00000),(47,29,9,'VENTA','LJ01','2020-08-06 00:00:00','01','F001-29',5.00,12.71186,'SU',986.00,10.00,9860.00,1,0.00000,0.00000),(48,30,9,'VENTA','LJ01','2020-08-06 00:00:00','01','F001-30',5.00,12.71186,'NIU',981.00,10.00,9810.00,1,0.00000,0.00000),(49,31,9,'VENTA','LJ01','2020-08-06 00:00:00','01','F001-31',5.00,12.71186,'NIU',976.00,10.00,9760.00,1,0.00000,0.00000),(50,32,13,'VENTA','VS012','2020-08-06 00:00:00','01','F001-32',6.00,169.49153,'NIU',7993.00,25.00,199825.00,1,0.00000,0.00000),(51,33,13,'VENTA','VS012','2020-08-06 00:00:00','01','F001-33',3.00,169.49153,'NIU',7990.00,25.00,199750.00,1,0.00000,0.00000),(52,34,13,'VENTA','VS012','2020-08-06 00:00:00','01','F001-34',3.00,169.49153,'NIU',7987.00,25.00,199675.00,1,0.00000,0.00000),(53,35,13,'VENTA','VS012','2020-08-06 00:00:00','01','F001-35',3.00,169.49153,'NIU',7984.00,25.00,199600.00,1,0.00000,0.00000),(54,36,13,'VENTA','VS012','2020-08-06 00:00:00','01','F001-36',3.00,169.49153,'NIU',7981.00,25.00,199525.00,1,0.00000,0.00000),(55,37,9,'VENTA','LJ01','2020-08-06 00:00:00','01','F001-37',3.00,12.71186,'NIU',973.00,10.00,9730.00,1,3.55000,0.00000),(56,38,9,'VENTA','LJ01','2020-08-10 00:00:00','01','F001-38',3.00,12.71186,'NIU',970.00,10.00,9700.00,1,3.55000,0.00000),(57,39,9,'VENTA','LJ01','2020-08-10 00:00:00','01','F001-39',3.00,12.71186,'NIU',967.00,10.00,9670.00,1,3.55000,0.00000),(58,40,9,'VENTA','LJ01','2020-08-10 00:00:00','01','F001-40',20.00,15.25424,'NIU',947.00,10.00,9470.00,1,0.00000,0.00000),(59,41,13,'VENTA','VS012','2020-08-10 00:00:00','01','F001-41',1.00,169.49153,'NIU',7980.00,25.00,199500.00,1,0.00000,0.00000),(60,42,4,'VENTA','PAA1','2020-08-10 00:00:00','01','F001-42',1.00,8.47458,'NIU',948.00,5.00,4740.00,1,0.00000,0.00000),(61,43,4,'VENTA','PAA1','2020-08-10 00:00:00','01','F001-43',10.00,8.47458,'NIU',938.00,5.00,4690.00,1,0.00000,0.00000),(62,44,9,'VENTA','LJ01','2020-08-10 00:00:00','01','F001-44',1.00,12.71186,'NIU',946.00,10.00,9460.00,1,0.00000,0.00000),(63,8,13,'VENTA','VS012','2020-08-10 00:00:00','03','B001-8',1.00,169.49153,'NIU',7979.00,25.00,199475.00,1,0.00000,0.00000),(64,9,9,'VENTA','LJ01','2020-08-10 00:00:00','03','B001-9',1.00,12.71186,'NIU',945.00,10.00,9450.00,1,0.00000,0.00000),(65,10,4,'VENTA','PAA1','2020-08-10 00:00:00','03','B001-10',1.00,8.47458,'NIU',937.00,5.00,4685.00,1,0.00000,0.00000),(66,11,9,'VENTA','LJ01','2020-08-10 00:00:00','03','B001-11',1.00,12.71186,'NIU',944.00,10.00,9440.00,1,0.00000,0.00000),(67,12,13,'VENTA','VS012','2020-08-10 00:00:00','03','B001-12',1.00,169.49153,'NIU',7978.00,25.00,199450.00,1,0.00000,0.00000),(68,45,9,'VENTA','LJ01','2020-08-11 00:00:00','01','F001-45',20.00,15.25424,'NIU',924.00,10.00,9240.00,1,0.00000,0.00000),(69,46,13,'VENTA','VS012','2020-08-12 00:00:00','01','F001-46',1.00,169.49153,'NIU',7977.00,25.00,199425.00,1,0.00000,0.00000),(70,13,4,'VENTA','PAA1','2020-08-12 00:00:00','03','B001-13',1.00,8.47458,'NIU',936.00,5.00,4680.00,1,0.00000,0.00000),(71,47,4,'VENTA','PAA1','2020-08-14 00:00:00','01','F001-47',1.00,8.47458,'NIU',935.00,5.00,4675.00,1,0.00000,0.00000);
/*!40000 ALTER TABLE `kardex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesa`
--

DROP TABLE IF EXISTS `mesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mesa` (
  `idmesa` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nromesa` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idmesa`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesa`
--

LOCK TABLES `mesa` WRITE;
/*!40000 ALTER TABLE `mesa` DISABLE KEYS */;
INSERT INTO `mesa` VALUES (1,'MESA10',NULL),(2,'MESA2',NULL),(3,'MESA3',NULL);
/*!40000 ALTER TABLE `mesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notacd`
--

DROP TABLE IF EXISTS `notacd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notacd` (
  `idnota` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numeroserienota` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `codigo_nota` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `codtiponota` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc_motivo` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_doc_mod` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `serie_numero` char(13) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_doc_ide` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `numero_doc_ide` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `razon_social` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_moneda` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `sum_ot_car` float(12,2) NOT NULL,
  `total_val_venta_og` float(12,2) NOT NULL,
  `total_val_venta_oi` float(12,2) NOT NULL,
  `total_val_venta_oe` float(12,2) NOT NULL,
  `sum_igv` float(12,2) NOT NULL,
  `sum_isc` float(12,2) NOT NULL,
  `sum_ot` float(12,2) NOT NULL,
  `importe_total` float(12,2) DEFAULT NULL,
  `estado` char(2) COLLATE utf8_unicode_ci DEFAULT '1',
  `idcomprobante` int(11) DEFAULT NULL,
  `fechacomprobante` datetime NOT NULL,
  `adicional` float(12,2) DEFAULT NULL,
  `idempresa` int(11) DEFAULT NULL,
  `vendedorsitio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `difComprobante` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icbper` float(14,2) DEFAULT NULL,
  `CodigoRptaSunat` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DetalleSunat` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivonota` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcambio` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`idnota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notacd`
--

LOCK TABLES `notacd` WRITE;
/*!40000 ALTER TABLE `notacd` DISABLE KEYS */;
/*!40000 ALTER TABLE `notacd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notapedido`
--

DROP TABLE IF EXISTS `notapedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notapedido` (
  `idboleta` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `fecha_emision_01` datetime NOT NULL,
  `firma_digital_36` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `idempresa` int(11) NOT NULL,
  `tipo_documento_06` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numeracion_07` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `codigo_tipo_15_1` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monto_15_2` float(12,2) DEFAULT NULL,
  `sumatoria_igv_18_1` float(12,2) DEFAULT NULL,
  `sumatoria_igv_18_2` float(12,2) DEFAULT NULL,
  `codigo_tributo_18_3` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_tributo_18_4` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_internacional_18_5` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `importe_total_23` float(12,2) NOT NULL,
  `codigo_leyenda_26_1` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion_leyenda_26_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_documento_25_1` int(11) DEFAULT NULL,
  `guia_remision_25` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_ubl_37` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version_estructura_38` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_moneda_24` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tasa_igv` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  `tipodocuCliente` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rucCliente` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RazonSocial` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `comentario_baja` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdescuento` float(12,2) DEFAULT NULL,
  `vendedorsitio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icbper` float(14,2) DEFAULT NULL,
  PRIMARY KEY (`idboleta`),
  UNIQUE KEY `numeracion_07` (`numeracion_07`),
  KEY `fk_boleta_empresa_idx` (`idempresa`),
  KEY `fk_boleta_usuario_idx` (`idusuario`),
  KEY `fk_boleta_usuario_idx1` (`idcliente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notapedido`
--

LOCK TABLES `notapedido` WRITE;
/*!40000 ALTER TABLE `notapedido` DISABLE KEYS */;
INSERT INTO `notapedido` VALUES (1,1,'2020-08-05 16:24:35','44477344',1,'50','NP01-1',1,'1001',30.00,0.00,0.00,'1000','IGV IM','VAT',30.00,'1000','DESCRIPCION DE LEYENDA',0,'','2.0','1.0','PEN','0.18',1,'0','99999999','CLIENTES VARIOS',NULL,NULL,0.00,'',NULL);
/*!40000 ALTER TABLE `notapedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numeracion`
--

DROP TABLE IF EXISTS `numeracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numeracion` (
  `idnumeracion` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_documento` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serie` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`idnumeracion`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numeracion`
--

LOCK TABLES `numeracion` WRITE;
/*!40000 ALTER TABLE `numeracion` DISABLE KEYS */;
INSERT INTO `numeracion` VALUES (1,'01','F001','47',1),(2,'03','B001','13',1),(3,'07','FF01','0',1),(4,'09','GR01','1',1),(5,'50','NP01','1',1),(6,'20','CT01','31',1),(7,'30','DC01','2',1);
/*!40000 ALTER TABLE `numeracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numeracionple`
--

DROP TABLE IF EXISTS `numeracionple`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numeracionple` (
  `ano` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `primerRegistro` int(11) DEFAULT NULL,
  `ultimoRegistro` int(11) DEFAULT NULL,
  `totalRegistros` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numeracionple`
--

LOCK TABLES `numeracionple` WRITE;
/*!40000 ALTER TABLE `numeracionple` DISABLE KEYS */;
INSERT INTO `numeracionple` VALUES ('2018',1,0,0);
/*!40000 ALTER TABLE `numeracionple` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenservicio`
--

DROP TABLE IF EXISTS `ordenservicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordenservicio` (
  `idorden` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `serienumero` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `idproveedor` int(11) NOT NULL,
  `fechaemision` datetime NOT NULL,
  `formapago` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `formaentrega` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `idempresa` int(11) NOT NULL,
  `fechaentrega` date NOT NULL,
  `anotaciones` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `subtotal` float(12,2) NOT NULL,
  `igv` float(12,2) NOT NULL,
  `total` float(12,2) NOT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idorden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenservicio`
--

LOCK TABLES `ordenservicio` WRITE;
/*!40000 ALTER TABLE `ordenservicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordenservicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidoplatos`
--

DROP TABLE IF EXISTS `pedidoplatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidoplatos` (
  `idpedido` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idmesa` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `nropedido` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravado` float(14,2) DEFAULT NULL,
  `igv` float(14,2) DEFAULT NULL,
  `total` float(14,2) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idpedido`),
  KEY `ref_pedcli` (`idcliente`),
  CONSTRAINT `ref_pedcli` FOREIGN KEY (`idcliente`) REFERENCES `persona` (`idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidoplatos`
--

LOCK TABLES `pedidoplatos` WRITE;
/*!40000 ALTER TABLE `pedidoplatos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidoplatos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permiso`
--

DROP TABLE IF EXISTS `permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permiso` (
  `idpermiso` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idpermiso`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permiso`
--

LOCK TABLES `permiso` WRITE;
/*!40000 ALTER TABLE `permiso` DISABLE KEYS */;
INSERT INTO `permiso` VALUES (1,'escritorio'),(2,'almacen'),(3,'ventas'),(4,'compras'),(5,'acceso'),(6,'consultac'),(7,'consultav'),(8,'inventarios'),(9,'kardex');
/*!40000 ALTER TABLE `permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persona`
--

DROP TABLE IF EXISTS `persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persona` (
  `idpersona` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_persona` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `nombres` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_documento` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numero_documento` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `razon_social` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `nombre_comercial` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domicilio_fiscal` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `departamento` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudad` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distrito` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono1` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `telefono2` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idpersona`),
  KEY `fk_persona_catalogo6_idx` (`tipo_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persona`
--

LOCK TABLES `persona` WRITE;
/*!40000 ALTER TABLE `persona` DISABLE KEYS */;
INSERT INTO `persona` VALUES (1,'cliente','CLIENTES VARIOS','CLIENTES VARIOS','0','99999999','CLIENTES VARIOS','CLIENTES VARIOS','-',NULL,NULL,NULL,'',NULL,NULL,1),(2,'cliente','','','6','20100088917','COMPAÑIA COMERCIAL ESTRELLA S A','COMPAÑIA COMERCIAL ESTRELLA S A','----PROLONGACION UNANUE NRO. 1418 URB. MATUTE LIMA - LIMA - LA VICTORIA','14','43','96','0','','@',1),(3,'cliente','-','-','6','20524682487','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','TEXTILES VIRGEN DEL CARMEN  E.I.R.L.','PRO.HUANUCO NRO. 1416 URB. EL POVENIR (ESQUINA CON AV 28 DE JULIO) LIMA - LIMA - LA VICTORIA','14','43','96','0','','tecnologosperu@gmail.com',1);
/*!40000 ALTER TABLE `persona` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platos`
--

DROP TABLE IF EXISTS `platos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platos` (
  `idplato` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idcategoria` int(11) NOT NULL,
  `codigo` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ctacontable` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `precio` float(12,2) DEFAULT NULL,
  `imagen` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idplato`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platos`
--

LOCK TABLES `platos` WRITE;
/*!40000 ALTER TABLE `platos` DISABLE KEYS */;
INSERT INTO `platos` VALUES (1,2,'PL01','ARROZ CON POLLO',NULL,8.00,'1575745633.jpg',1),(2,2,'PL02','ARROZ / MARISCOS',NULL,18.00,'1575746476.jpg',1),(3,2,'PL03','JALEA MIXTA',NULL,22.00,'1575999312.jpg',1),(4,2,'PT04','SOPA SECA',NULL,25.00,'1576700601.jpg',1),(5,1,'PT05','TALARRIN SALTADO',NULL,25.00,'1576700797.jpg',1),(6,1,'PT06','SOPA A LA MINUTA',NULL,15.00,'1576700946.jpg',1),(7,1,'PT07','SECO C/CABRITO',NULL,45.00,'1576700971.jpg',1),(8,1,'PT08','ESTOFADO',NULL,20.00,'1576700995.jpg',1),(9,1,'PT09','PACHAMANCA',NULL,50.00,'1576701012.jpg',1),(10,2,'PL10','LENJEJAS CON ARROZ',NULL,10.00,'1577136481.jpg',1);
/*!40000 ALTER TABLE `platos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrocopiabd`
--

DROP TABLE IF EXISTS `registrocopiabd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrocopiabd` (
  `idregistro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecharegistro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nombrearchivo` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usuario` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idregistro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrocopiabd`
--

LOCK TABLES `registrocopiabd` WRITE;
/*!40000 ALTER TABLE `registrocopiabd` DISABLE KEYS */;
/*!40000 ALTER TABLE `registrocopiabd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rutas`
--

DROP TABLE IF EXISTS `rutas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rutas` (
  `idruta` int(11) NOT NULL AUTO_INCREMENT,
  `rutadata` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutafirma` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutaenvio` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutarpta` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutadatalt` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutabaja` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutaresumen` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutadescargas` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutaple` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idempresa` int(11) DEFAULT NULL,
  `unziprpta` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idruta`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rutas`
--

LOCK TABLES `rutas` WRITE;
/*!40000 ALTER TABLE `rutas` DISABLE KEYS */;
INSERT INTO `rutas` VALUES (1,'..\\sfs\\data\\','..\\sfs\\firma\\','..\\sfs\\envio\\','..\\sfs\\rpta\\','..\\sfs\\dataalterna\\','..\\sfs\\baja\\','..\\sfs\\resumen\\','..\\sfs\\descargas\\','..\\sfs\\ple\\',1,'..\\sfs\\unziprpta\\');
/*!40000 ALTER TABLE `rutas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salidacaja`
--

DROP TABLE IF EXISTS `salidacaja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salidacaja` (
  `idsalida` int(11) NOT NULL AUTO_INCREMENT,
  `idcaja` int(11) NOT NULL,
  `concepto` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monto` float(14,2) DEFAULT NULL,
  `tipo` char(20) COLLATE utf8_unicode_ci DEFAULT 'SALIDA',
  PRIMARY KEY (`idsalida`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salidacaja`
--

LOCK TABLES `salidacaja` WRITE;
/*!40000 ALTER TABLE `salidacaja` DISABLE KEYS */;
/*!40000 ALTER TABLE `salidacaja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicios_inmuebles`
--

DROP TABLE IF EXISTS `servicios_inmuebles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicios_inmuebles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valor` float(12,5) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT '1',
  `idempresa` int(11) DEFAULT NULL,
  `tipo` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ccontable` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicios_inmuebles`
--

LOCK TABLES `servicios_inmuebles` WRITE;
/*!40000 ALTER TABLE `servicios_inmuebles` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicios_inmuebles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sunatconfig`
--

DROP TABLE IF EXISTS `sunatconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sunatconfig` (
  `idcarga` int(11) NOT NULL AUTO_INCREMENT,
  `numeroruc` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `razon_social` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usuarioSol` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `claveSol` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutacertificado` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutaserviciosunat` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombrepem` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idcarga`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sunatconfig`
--

LOCK TABLES `sunatconfig` WRITE;
/*!40000 ALTER TABLE `sunatconfig` DISABLE KEYS */;
INSERT INTO `sunatconfig` VALUES (1,'20603504969','TECNOLOGOS PERU E.I.R.L.','MODDATOS','Camila4720383','../certificado/','https://e-beta.sunat.gob.pe/ol-ti-itcpfegem-beta/billService?wsdl','tecnologos.pem');
/*!40000 ALTER TABLE `sunatconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcambio`
--

DROP TABLE IF EXISTS `tcambio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tcambio` (
  `idtipocambio` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `compra` float(14,3) NOT NULL,
  `venta` float(14,3) NOT NULL,
  PRIMARY KEY (`idtipocambio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tcambio`
--

LOCK TABLES `tcambio` WRITE;
/*!40000 ALTER TABLE `tcambio` DISABLE KEYS */;
/*!40000 ALTER TABLE `tcambio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tempnumeracionxml`
--

DROP TABLE IF EXISTS `tempnumeracionxml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempnumeracionxml` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `numero` int(11) DEFAULT '0',
  `numticket` varchar(100) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `comentario` varchar(100) DEFAULT NULL,
  `nombrebaja` varchar(100) DEFAULT NULL,
  `comprobante` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempnumeracionxml`
--

LOCK TABLES `tempnumeracionxml` WRITE;
/*!40000 ALTER TABLE `tempnumeracionxml` DISABLE KEYS */;
INSERT INTO `tempnumeracionxml` VALUES (1,'2019-10-11',0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tempnumeracionxml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporal_articulo`
--

DROP TABLE IF EXISTS `temporal_articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporal_articulo` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `um` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cant` float(12,2) DEFAULT NULL,
  `costo_c` float(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporal_articulo`
--

LOCK TABLES `temporal_articulo` WRITE;
/*!40000 ALTER TABLE `temporal_articulo` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporal_articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporizador`
--

DROP TABLE IF EXISTS `temporizador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporizador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiempo` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporizador`
--

LOCK TABLES `temporizador` WRITE;
/*!40000 ALTER TABLE `temporizador` DISABLE KEYS */;
INSERT INTO `temporizador` VALUES (1,0,0);
/*!40000 ALTER TABLE `temporizador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umedida`
--

DROP TABLE IF EXISTS `umedida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umedida` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `abre` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umedida`
--

LOCK TABLES `umedida` WRITE;
/*!40000 ALTER TABLE `umedida` DISABLE KEYS */;
INSERT INTO `umedida` VALUES (1,'UNIDAD','NIU'),(2,'MTS','MTS'),(3,'KLO','KL'),(4,'BALON','BLN'),(5,'CAJA','CJA'),(6,'SU','SU');
/*!40000 ALTER TABLE `umedida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_documento` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num_documento` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cargo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clave` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imagen` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condicion` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`idusuario`),
  UNIQUE KEY `login_UNIQUE` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'ADMIN','ADMIN','DN','0000000','.','.','.','.','ADMIN','8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918','1515506289.jpg',1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_empresa`
--

DROP TABLE IF EXISTS `usuario_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_empresa` (
  `idusuario` int(11) NOT NULL,
  `idempresa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_empresa`
--

LOCK TABLES `usuario_empresa` WRITE;
/*!40000 ALTER TABLE `usuario_empresa` DISABLE KEYS */;
INSERT INTO `usuario_empresa` VALUES (1,1);
/*!40000 ALTER TABLE `usuario_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_permiso`
--

DROP TABLE IF EXISTS `usuario_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_permiso` (
  `idusuario_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL,
  `idpermiso` int(11) NOT NULL,
  PRIMARY KEY (`idusuario_permiso`),
  KEY `fk_permiso_detalle_idx` (`idpermiso`),
  KEY `fk_usuario_detalle_idx` (`idusuario`),
  CONSTRAINT `fk_permiso_detalle` FOREIGN KEY (`idpermiso`) REFERENCES `permiso` (`idpermiso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_detalle` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_permiso`
--

LOCK TABLES `usuario_permiso` WRITE;
/*!40000 ALTER TABLE `usuario_permiso` DISABLE KEYS */;
INSERT INTO `usuario_permiso` VALUES (17,1,1),(18,1,2),(19,1,3),(20,1,4),(21,1,5),(22,1,8),(23,1,9);
/*!40000 ALTER TABLE `usuario_permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valfinarticulo`
--

DROP TABLE IF EXISTS `valfinarticulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `valfinarticulo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idempresa` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `codigoart` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ano` int(11) NOT NULL,
  `costoi` float(14,2) NOT NULL,
  `saldoi` float(14,2) NOT NULL,
  `valori` float(14,2) NOT NULL,
  `costof` float(14,2) NOT NULL,
  `saldof` float(14,2) NOT NULL,
  `valorf` float(14,2) NOT NULL,
  `fechag` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valfinarticulo`
--

LOCK TABLES `valfinarticulo` WRITE;
/*!40000 ALTER TABLE `valfinarticulo` DISABLE KEYS */;
INSERT INTO `valfinarticulo` VALUES (27,1,13,'VS012',2020,25.00,8000.00,200000.00,0.00,7977.00,0.00,'2020-08-13');
/*!40000 ALTER TABLE `valfinarticulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendedorsitio`
--

DROP TABLE IF EXISTS `vendedorsitio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendedorsitio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT '1',
  `idempresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendedorsitio`
--

LOCK TABLES `vendedorsitio` WRITE;
/*!40000 ALTER TABLE `vendedorsitio` DISABLE KEYS */;
/*!40000 ALTER TABLE `vendedorsitio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-15 12:48:42
